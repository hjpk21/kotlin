package com.kaybo1.dev.kotlintest.fragmemts

import org.junit.Test

import org.junit.Assert.*

/**
 * Created by Administrator on 2017-11-28.
 */
class SampleFragmentTest {
    @Test
    fun onCreateView() {
    }

    @Test
    fun onViewCreated() {
    }

    @Test
    fun onCreateOptionsMenu() {
    }

}