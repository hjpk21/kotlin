package com.kaybo1.dev.kotlintest.postDetailDummy.presenter

import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import retrofit2.Call
import tech.thdev.base.presenter.AbstractPresenter
import retrofit2.Callback
import retrofit2.Response

/**
 * Created by Administrator on 2018-02-27.
 */
class PostDummyPresenter : AbstractPresenter<PostDummyContract.View>(), PostDummyContract.Presenter {
    override var postDetailDataSource: PostDetailDataSource? = null

    private var backItem : PostDetailResponse? = null

    override fun loadThumbInfo(thumb: Int) {
        postDetailDataSource?.getPostDetailResponse(thumb)?.enqueue(object : Callback<PostDetailResponse>{
            override fun onFailure(call: Call<PostDetailResponse>?, t: Throwable?) {
                //fail
            }

            override fun onResponse(call: Call<PostDetailResponse>?, response: Response<PostDetailResponse>?) {
                if(response?.isSuccessful ?: false){
                    response?.body()?.let {
                        backItem = it
                        view?.updateItem(it)
                    }
                }
            }

        })
    }

}