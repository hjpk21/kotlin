package com.kaybo1.dev.kotlintest.base.adapter

import android.content.Context

import com.kaybo1.dev.kotlintest.models.ToolbarListType

/**
 * Created by Administrator on 2017-12-01.
 */
class BaseAdapter (private val context:Context, listType: ToolbarListType){
    fun selectView(listType: ToolbarListType) = when(listType){
        ToolbarListType.All -> changeView(context)
                else -> changeView(context)
    }
    fun changeView(context: Context) {

    }
}