package com.kaybo1.dev.kotlintest.home.view.data

import android.util.Log
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2017-12-06.
 */
data class ShortCutList (val homeShortcutId : String,
                         val title : String,
                         var imageUrl : String,
                         val linkUrl : String,
                         val createDate : Any){
    fun getShortCutImage() : String{
        if(imageUrl != null ){
            if(imageUrl.startsWith("http")){
                imageUrl
            }else{
                imageUrl = BuildConfig.KAYBO_REAL_URL+"$imageUrl"
            }
        }
        //Log.d("ShortCut Image",imageUrl)
        return imageUrl
    }
}