package com.kaybo1.dev.kotlintest.PostDetail

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import com.kaybo1.dev.kotlintest.PostDetail.adapter.PostContentsPagerAdapter
import com.kaybo1.dev.kotlintest.PostDetail.adapter.PostDetailResponseAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.Member
import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsPagerAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailContract
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailPresenter
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.fragment_post_detail.*
import tech.thdev.base.view.BaseFragment
import tech.thdev.base.view.BasePresenterFragment

/**
 * Created by Administrator on 2018-02-27.
 */
@SuppressLint("LongLogTag")
class PostDetailFragment(context : Context) : BaseFragment(){

    override fun getLayout(): Int = R.layout.fragment_post_detail

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d("TAG : [PostDetailFragment] ","onViewCreated = ")
    }

}