package com.kaybo1.dev.kotlintest.home.view.data

/**
 * Created by Administrator on 2017-11-28.
 */
data class Info (val recommendTitle : String,
                 val recommendThemeTitle: String,
                 val recommendThemeContent: String,
                 val communityTitle: String,
                 val comicTitle:String
)