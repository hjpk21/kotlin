package com.kaybo1.dev.kotlintest.network

import com.kaybo1.dev.kotlintest.home.view.data.HomeResponse
import retrofit2.Call
import retrofit2.http.GET

/**
 * Created by Administrator on 2017-11-30.
 */
interface MainServiceInterface {
    @GET("api/homeList")
    fun getAllSectionLists():Call<HomeResponse>
}
