package com.kaybo1.dev.kotlintest.home.view.data

/**
 * Created by Administrator on 2017-11-28.
 */
data class HomeResponse(
        val info : Info,
        val code : String,
        val bannerList : ArrayList<BannerList>,
        val channelList: ArrayList<ChannelList>,
        val shortCutList: ArrayList<ShortCutList>,
        val noticeList: ArrayList<NoticeList>,
        val homeCartoonList: ArrayList<HomeCartoonList>)