package com.kaybo1.dev.kotlintest.home.view.adapter.holder

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.home.view.adapter.HomeCartoonViewAdapter
import com.kaybo1.dev.kotlintest.home.view.data.HomeCartoonList
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_single.view.*


/**
 * Created by Administrator on 2017-12-06.
 */
@SuppressLint("LongLogTag")
class HomeCartoonViewHolder(context: Context, parent: ViewGroup?, var onItemClickListener: OnItemClickListener?) :
        BaseViewHolder<HomeCartoonList>(R.layout.list_single, context,parent) {
    override fun bindView(item: HomeCartoonList?, position: Int) {
        itemView?.let {
            with(it){
                ImageDownload.loadImage(R.drawable.loading, image, item?.getHomeCartoonImage())
               /* Glide.with(context)
                .load(item?.getHomeCartoonImage())
                    .centerCrop()
                    .placeholder(R.drawable.sample_00)
                    .into(image)*/
            }
            it.setOnTouchListener { view, motionEvent ->
                onItemClickListener?.onItemClick(motionEvent,position) ?: false
            }
        }
    }

    /*fun bindView(item: HomeCartoonList?, position:Int){
        itemView?.let {
            with(it){
                ImageDownload.loadImage(R.drawable.loading, image, item?.getHomeCartoonImage())
                *//*Glide.with(context)
                        .load(item?.getHomeCartoonImage())
                        .centerCrop()
                        .placeholder(R.drawable.sample_00)
                        .into(image)*//*
            }
            it.setOnTouchListener { view, motionEvent ->
                onItemClickListener?.onItemClick(motionEvent,position) ?: false
            }
        }

    }*/


}