package com.kaybo1.dev.kotlintest.Channel.data.model

/**
 * Created by Administrator on 2018-01-23.
 */
data class ChannelResponse (val boardId : String,
                            val name : String,
                            val type : String,
                            val detail : Detail,
                            val channel : Channel)