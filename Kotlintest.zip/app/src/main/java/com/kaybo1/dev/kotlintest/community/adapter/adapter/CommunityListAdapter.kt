package com.kaybo1.dev.kotlintest.community.adapter.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.R.id.itemTitle
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.community.adapter.adapter.holder.CommunityViewHolder
import com.kaybo1.dev.kotlintest.community.adapter.adapter.model.CommunityListAdapterContract
import com.kaybo1.dev.kotlintest.community.adapter.data.model.*
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityContract
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener


/**
 * Created by Administrator on 2017-12-28.
 */
class CommunityListAdapter (private val context:Context) : RecyclerView.Adapter<BaseViewHolder<AllChannel>>(),
        CommunityListAdapterContract.AllChannelListModel, CommunityListAdapterContract.AllChannelListView {
    override fun getItems(): ArrayList<AllChannel> = itemList

    override fun getItem(postion: Int): AllChannel = itemList[postion]

    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                return onTouch(motionEvent,postion)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<AllChannel>?= CommunityViewHolder(context,parent,onItemTouchListener)

    override fun onBindViewHolder(holder: BaseViewHolder<AllChannel>?, position: Int) {
        holder?.bindView(getItem(position),position)
    }

    override fun clear() {
        itemList.clear()
    }

    /*override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): CommunityViewHolder {
        return CommunityViewHolder(context,parent)
    }

    override fun onBindViewHolder(holder: CommunityViewHolder?, position: Int) {
        holder?.bindView(getCommunityItem(position),position)
    }*/

    override fun addAllChannelListItem(item: AllChannel) {
        //itemAllChannel.add(item)
        item?.let {
            itemList.add(it)
        }
    }

    /*override fun getItemCount(): Int  {
        return if(item == null) 0 else item
    }*/
    override fun getItemCount(): Int = itemList.size

    val itemList : ArrayList<AllChannel> = ArrayList()

        override fun reload() {
            notifyDataSetChanged()
        }
        /*override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): CommunityListViewHolder {
            Log.d("CommunityListAdapter","onCrateViewHolder $viewType")
            //setCommunityItem()
            val vv = LayoutInflater.from(parent?.context).inflate(R.layout.list_community, parent,false)
            val mf= CommunityListViewHolder(vv)
            return mf
        }

        override fun onBindViewHolder(holder: CommunityListViewHolder?, position: Int) {
            Log.d("CommunityListAdapter","onBindViewHolder = $holder")
            holder?.itemTitle?.text = getCommunityItem(position).title
            *//*Glide.with(context)
                    .load(getCommunityItem(position).getImage())
                    .centerCrop()
                    .placeholder(R.drawable.sample_00)
                    .into(holder?.image)*//*
        }*/

       /* override fun getItemCount(): Int  {
            Log.d("getItemCount","")
            return item!!
        }*/

            inner class CommunityListViewHolder(view : View) : RecyclerView.ViewHolder(view),View.OnClickListener{
                override fun onClick(v: View?) {

                }

                val itemTitle : TextView
                //val recycler_view_list : RecyclerView
                val image : ImageView

                init {
                    itemTitle = view.findViewById(R.id.title)
                    //recycler_view_list = view.findViewById(R.id.recycler_view_list)
                    image = view.findViewById(R.id.image)
                }
            }
        }
