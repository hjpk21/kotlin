package com.kaybo1.dev.kotlintest.base.util

import android.content.Context
import android.content.Intent
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import com.kaybo1.dev.kotlintest.Channel.ChannelIdActivity
import com.kaybo1.dev.kotlintest.LoginActivity
import com.kaybo1.dev.kotlintest.Kcoin.KcoinActivity
import com.kaybo1.dev.kotlintest.PostDetail.DummyPostDetailActivity
import com.kaybo1.dev.kotlintest.PostDetail.PostDetailActivity
import com.kaybo1.dev.kotlintest.postDetailDummy.PostDummyActivity


/**
 * Created by Administrator on 2018-01-18.
 */
fun AppCompatActivity.replaceFragmentToActivity(fragment: Fragment, fragmentId : Int){
    val transation = this.supportFragmentManager.beginTransaction()
    transation.replace(fragmentId,fragment)
    transation.commit()
}

/*fun Context.createDetailIntent(list:ArrayList<AllChannel>,position:Int) : Intent {
    return
}*/

fun Context.createLoginIntent() : Intent {
    return Intent(this,LoginActivity::class.java)
}

fun Context.createChannelInfoIntent(channelId : String) : Intent {
    return Intent(this,ChannelIdActivity::class.java).apply {
        putExtra("channelId",channelId)
    }
}
fun Context.createKcoinIntent(token : String) : Intent {
    return Intent(this, KcoinActivity::class.java).apply {
        putExtra("token",token)
    }
}

fun Context.createPostDetailIntent(postId : String) : Intent {
    return Intent(this,PostDetailActivity::class.java).apply {
        putExtra("postId",postId)
    }
}
fun Context.createPostDummyIntent(postId : String) : Intent {
    return Intent(this,DummyPostDetailActivity::class.java).apply {
        putExtra("postId",postId)
    }
}