package com.kaybo1.dev.kotlintest.models

/**
 * Created by Administrator on 2017-12-12.
 */
enum class CouponToolbarListType {
    PcGame,
    MobileGame,
    MyCoupon
}