package com.kaybo1.dev.kotlintest.Kcoin.presenter

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Kcoin.adapter.model.DummyLoginModel
import com.kaybo1.dev.kotlintest.Kcoin.data.KcoinDataSource
import com.kaybo1.dev.kotlintest.Kcoin.data.model.Balance
import com.kaybo1.dev.kotlintest.home.view.data.DummyListFactory
import retrofit2.Call
import tech.thdev.base.presenter.AbstractPresenter
import retrofit2.Callback
import retrofit2.Response

/**
 * Created by Administrator on 2018-02-26.
 */
@SuppressLint("LongLogTag")
class KcoinPresenter : AbstractPresenter<KcoinContract.View>(), KcoinContract.Presenter {
    private val handler = Handler(Looper.getMainLooper())

    override var dummyLoginModel: DummyLoginModel? = null
        set(value) {
            Log.d("TAG :[KcoinPresenter] ","dummyLoginModel = "+value)
            field = value

            field?.setOnItemTouchListener { motionEvent, i -> onItemTouchEvent(motionEvent,i) }
        }
    override var kcoinDataSource: KcoinDataSource? = null

    private var balanceItem : Balance? = null

    override fun loadKcoinBalance() {
        kcoinDataSource?.getKcoinBalance()?.enqueue(object : Callback<Balance>{
            override fun onFailure(call: Call<Balance>?, t: Throwable?) {
                //fail
            }

            override fun onResponse(call: Call<Balance>?, response: Response<Balance>?) {
                if (response?.isSuccessful ?:false){
                    Log.d("TAG : [KcoinPresenter] ","onResponse"+response?.raw().toString())
                    response?.body()?.let {
                        balanceItem = it
                        view?.updateItem(it)
                    }
                }else{
                        view?.dummyLogin(dummyListFactory.loginDummyLists)
                }
            }

        })
    }
    var dummyListFactory: DummyListFactory = DummyListFactory()
    var posX: Float = 0.0f
    var posY: Float = 0.0f
    private fun onItemTouchEvent(motionEvent: MotionEvent?, position: Int): Boolean {
        when (motionEvent?.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({
                    Log.i("TAG", "500!!!!")
                    val item = dummyLoginModel?.dummyList
                    item?.let {
                        //view?.showChannelDetail(item.channelId)
                        //startActivity(context.createChannelInfoIntent(2))
                    }
                }, 300L)
                motionEvent?.let {
                    onAdapterClick(position)

                }
                posX = motionEvent?.x ?: 0f
                posY = motionEvent?.y ?: 0f
            }
        }
        return true
    }
    private fun onAdapterClick(postion : Int) {
        dummyLoginModel?.dummyList?.let {
            view?.changePage(it.get(postion).Id)
            //view?.setPostList(it)
        }
    }

}