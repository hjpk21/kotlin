package com.kaybo1.dev.kotlintest.Channel.presenter

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Channel.adapter.model.ChannelInfoListModel
import com.kaybo1.dev.kotlintest.Channel.adapter.model.PostListModel
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.ChannelInfoDataSource
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import tech.thdev.base.presenter.BasePresenter
import tech.thdev.base.presenter.BaseView

/**
 * Created by Administrator on 2018-01-18.
 */
interface ChannelIdContract {


    interface View : BaseView  {
        fun setItem(item : ChannelInfo)
        fun setChannelInfo(item:ChannelResponse,ltems: List<ChannelResponse>)
		fun setPostList(item:List<PostList>)
        //click event
        fun setChannelNum(postId : Int)
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)

    }
    interface Presenter : BasePresenter<View>{
        var channelInfoDataSource : ChannelInfoDataSource?

        var channelInfoListModel : ChannelInfoListModel?

        var postListModel : PostListModel?

        fun loadChannelInfo(channelId : Int)

        fun loadChannelPostList(boardId: Int)

        fun loadChannelPostLists(boardId:Int,categoryId:Int,pageable:Int,size:Int)

        fun setPostList(item:List<PostList>)

        fun destroy()

    }
    interface Model{
        fun additem(item:ChannelResponse)
    }


}