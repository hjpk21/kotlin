package com.kaybo1.dev.kotlintest.PostDetail

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsPagerAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.presenter.DummyContract
import com.kaybo1.dev.kotlintest.PostDetail.presenter.DummyPresenter
import com.kaybo1.dev.kotlintest.R
import kotlinx.android.synthetic.main.fragment_post_detail.*
import tech.thdev.base.view.BasePresenterFragment

/**
 * Created by Administrator on 2018-03-02.
 */
class DummyPostDetailFragment(passedContext: Context) : BasePresenterFragment<DummyContract.View,DummyContract.Presenter>(),DummyContract.View {
    override fun updateItem(item: PostDetailResponse) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun commentItem(item: List<CommentsResponse>) {
        commentsPagerAdapter = CommentsPagerAdapter(passThroughContext,item)
        postDetail_recycler.adapter = commentsPagerAdapter
        postDetail_recycler.layoutManager = LinearLayoutManager(passThroughContext,LinearLayoutManager.VERTICAL,false)
    }

    override fun getLayout(): Int = R.layout.fragment_post_detail

    override fun onCreatePresenter() = DummyPresenter()

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter?.postDetailDataSource
        val postId = this.arguments.getInt("postId")
        presenter?.loadComments(postId)

    }

    companion object {
        fun newInstance(context: Context,postId : Int) : DummyPostDetailFragment {
            val fragment = DummyPostDetailFragment(context)
            val args = Bundle()
            args.putInt("postId",postId)
            fragment.arguments = args
            return fragment
        }
    }

    val passThroughContext : Context = passedContext
    var commentsPagerAdapter : CommentsPagerAdapter? = null
}