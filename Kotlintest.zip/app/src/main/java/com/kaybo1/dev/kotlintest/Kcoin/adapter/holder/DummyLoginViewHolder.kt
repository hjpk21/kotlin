package com.kaybo1.dev.kotlintest.Kcoin.adapter.holder

import android.content.Context
import android.support.v7.widget.DecorContentParent
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.home.view.data.DummyList
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_login.view.*

/**
 * Created by Administrator on 2018-02-26.
 */
class DummyLoginViewHolder(context: Context,parent: ViewGroup?,val onItemClickListener: OnItemClickListener?) : BaseViewHolder<DummyList>(R.layout.list_login,context,parent){
    override fun bindView(item: DummyList?, position: Int) {
        itemView?.let {
            with(it){
                ImageDownload.loadImage(R.drawable.loading,ivDelete,item?.url)
                tvTitle.text = item?.name

                it.setOnTouchListener { view, motionEvent ->
                    onItemClickListener?.onItemClick(motionEvent,position) ?: false
                }
            }
        }
    }

}