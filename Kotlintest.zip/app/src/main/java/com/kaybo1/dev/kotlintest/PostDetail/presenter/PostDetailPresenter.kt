package com.kaybo1.dev.kotlintest.PostDetail.presenter

import android.annotation.SuppressLint
import android.util.Log
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.CommentsPagerModel
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostContentsPagerModel
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostDetailReponseModel
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import tech.thdev.base.presenter.AbstractPresenter

/**
 * Created by Administrator on 2018-02-19.
 */
@SuppressLint("LongLogTag")
class PostDetailPresenter : AbstractPresenter<PostDetailContract.View>(), PostDetailContract.Presenter {
    override var postContentsPagerModel: PostContentsPagerModel? = null

    override var postDetailResponseModel: PostDetailReponseModel?= null

    override var commentsPagerModel: CommentsPagerModel? = null

    override var postDetailDataSource: PostDetailDataSource? = null

    override fun loadPostDetail(postId: Int) {
        postDetailDataSource?.getPostDetailResponse(postId)?.enqueue(object : Callback<PostDetailResponse> {

            override fun onFailure(call: Call<PostDetailResponse>?, t: Throwable?) {
                Log.d("TAG : [PostDetailPresenter] ","loadPostDetail FAIL = " + t.toString())
            }
            override fun onResponse(call: Call<PostDetailResponse>?, response: Response<PostDetailResponse>?) {
                if(response?.isSuccessful ?: false){
                    response?.body()?.let {
                        Log.d("TAG : [PostDetailPresenter] ","loadPostDetail Response:"+it)
                        //postDetailResponseModel?.item(it)
                        view?.updateItem(it)
                        //view?.responseItem(it.postContents)
                    }
                }
            }

        })
    }

    override fun loadComments(postId: Int) {
        postDetailDataSource?.getPostCommentResponse(postId)?.enqueue(object : Callback<List<CommentsResponse>>{
            override fun onResponse(call: Call<List<CommentsResponse>>?, response: Response<List<CommentsResponse>>?) {
                if(response?.isSuccessful ?: false){
                    response?.body()?.let {
                        Log.d("TAG : [PostDetailPresenter] ","loadComments Response:"+it)
                        commentsPagerModel?.commentsResponse = it
                        view?.commentItem(it)

                    }
                }
            }

            override fun onFailure(call: Call<List<CommentsResponse>>?, t: Throwable?) {
                Log.d("TAG : [PostDetailPresenter] ","loadComments FAIL = " + t.toString())
            }

        })
    }
}
