package com.kaybo1.dev.kotlintest.home.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent

import android.view.View
import android.view.ViewGroup

import android.widget.TextView
import android.widget.Toast

import com.kaybo1.dev.kotlintest.R

import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.*

import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener


/**
 * Created by Administrator on 2017-12-01.
 */
@SuppressLint("LongLogTag")
class HomeListAdapter (private val context: Context) : RecyclerView.Adapter<HomeListAdapter.HomeListViewHolder>(), ViewAdapterContract.Model, ViewAdapterContract.View{
    override var onItemTouchListener: OnItemClickListener? = null


    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                Log.d("TAG : [ChannelIdActivity]","onItemClick : "+postion)
                return onTouch(motionEvent,postion)
            }
        }
    }

    /*override fun showLoadFailMessage(message: String) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showHomeCartoonLInk(linkUrl: String) {
        Log.d("TAG : [HomeListAdapter]","SampleCotract.View")
        var i = Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl))
        context.startActivity(i)
    }*/

    override fun addDummyItem(item: DummyList) {
        itemDummy.add(item)
    }

    override fun getItemCount() = itemDummy.size

    override fun addInfoItem(item: Info) {
        //Log.d("TAG : HomeListAdapter ","addInfoItem"+item.toString())
        itemInfo?.add(item)
    }


    override fun addHomeResponse(item: HomeResponse) {
        //Log.d("TAG : HomeListAdapter ","addHomeResponse"+item.toString())
        itemHomeResponse?.add(item)
    }

    override fun addChannelItem(item: ChannelList) {
        //Log.d("TAG : HomeListAdapter ","addChannelItem"+item.toString())
        itemChannel.add(item)
    }

    override fun addNoticeItem(item: NoticeList) {
        //Log.d("TAG : HomeListAdapter ","addNoticeItem"+item.toString())
        itemNotice.add(item)
    }

    override fun addShortCutItem(item: ShortCutList) {
        //Log.d("TAG : HomeListAdapter ","addShortCutItem"+item.toString())
        itemShortCut.add(item)
    }

    override fun addHomeCartoonItem(item: HomeCartoonList) {
        //Log.d("TAG : HomeListAdapter ","addHomeCartoonItem"+item.toString())
        itemHomeCartoon.add(item)
        presenter?.adapterHomeCartoonModel?.addHomeCartoonItem(item)
    }

    /*override fun showLoadSuccess() {
        Toast.makeText(context, "Load success", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFail() {
        Toast.makeText(context, "Load fail", Toast.LENGTH_SHORT).show()
    }*/

    override fun Modelclear() {
        itemInfo.clear()
    }

    /*override fun showLoadFailMessage(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        Log.e("TAG", "Exception : " + message)
    }*/

    override fun Viewreload() {
        notifyDataSetChanged()
    }

    var itemHomeResponse : MutableList<HomeResponse> = ArrayList()
    val itemNotice : MutableList<NoticeList> = ArrayList()
    val itemInfo : MutableList<Info> = ArrayList()
    val itemChannel : MutableList<ChannelList> = ArrayList()
    val itemShortCut : MutableList<ShortCutList> = ArrayList()
    val itemHomeCartoon : MutableList<HomeCartoonList> = ArrayList()
    val itemDummy : MutableList<DummyList> = ArrayList()




    private var channelAdapter : ChannelAdapter? = null
    private var homeCartoonViewAdapter : HomeCartoonViewAdapter? = null

    private var shortCutListViewAdapter : ShortCutViewAdapter? = null
    private var channelListViewAdapter : ChannelViewAdapter? = null

    private var presenter : SampleContract.Presenter? = null


    override fun onBindViewHolder(holder: HomeListViewHolder?, position: Int) {
        when(position){
            0 -> {
                //presenter = SamplePresenter()
                //holder?.itemTitle?.text = itemInfo.get(0).comicTitle
                holder?.itemTitle?.text = "Manga gratis de hoy"
                holder?.itemTitle2?.text = "Ver mas >"
                holder?.itemTitle2?.setOnClickListener {
                    var i = Intent(Intent.ACTION_VIEW, Uri.parse("http://realcomics.kaybo1.com"))
                    context.startActivity(i)
                }
                homeCartoonViewAdapter = HomeCartoonViewAdapter(context,itemHomeCartoon,onItemTouchListener)

                holder?.recycler_view_list?.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
                holder?.recycler_view_list?.adapter = homeCartoonViewAdapter
            }
            1 -> {
                //presenter = SamplePresenter()
                holder?.itemTitle?.text = itemInfo.get(0).recommendTitle
                holder?.itemTitle2?.text = ""
                shortCutListViewAdapter = ShortCutViewAdapter(context,itemShortCut)

                holder?.recycler_view_list?.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
                holder?.recycler_view_list?.adapter = shortCutListViewAdapter
            }
            2 -> {
                holder?.itemTitle?.text = itemInfo.get(0).communityTitle
                holder?.itemTitle2?.text = ""
                channelListViewAdapter = ChannelViewAdapter(context,itemChannel)


                holder?.recycler_view_list?.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false)
                holder?.recycler_view_list?.adapter = channelListViewAdapter

            }
            3 -> {
                holder?.itemTitle2?.text = ""
                holder?.itemTitle?.text = itemNotice.get(0).noticeDate as CharSequence?
            }
            else -> Log.d("TAG HomeListAdapter","Dummy : "+itemDummy.toString())
        }


        /*Glide.with(context)
                .load(getHomeCartoonImage(position).getHomeCartoonImage())
                .centerCrop()
                .placeholder(R.drawable.sample_00)
                .into(holder?.image)*/
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): HomeListViewHolder {
        val vv = LayoutInflater.from(parent?.context).inflate(R.layout.list_item,null)
        val mf = HomeListViewHolder(vv)

        return mf
    }



    inner class HomeListViewHolder(view : View) : RecyclerView.ViewHolder(view) {
        val itemTitle: TextView
        val itemTitle2 :TextView
        val recycler_view_list : RecyclerView

        init {
            itemTitle = view.findViewById(R.id.itemTitle)
            itemTitle2 = view.findViewById(R.id.itemTitle2)
            recycler_view_list = view.findViewById(R.id.recycler_view_list)
        }
}
}