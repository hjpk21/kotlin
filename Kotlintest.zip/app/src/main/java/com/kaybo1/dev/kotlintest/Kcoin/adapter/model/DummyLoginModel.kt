package com.kaybo1.dev.kotlintest.Kcoin.adapter.model

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.home.view.data.DummyList
import com.kaybo1.dev.kotlintest.home.view.data.DummyListFactory
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-26.
 */
interface DummyLoginModel {
    var dummyList : ArrayList<DummyList>?
    val onItemTouchListener : OnItemClickListener?
    fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)

}