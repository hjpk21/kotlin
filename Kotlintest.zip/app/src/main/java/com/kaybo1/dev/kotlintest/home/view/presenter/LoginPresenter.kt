package com.kaybo1.dev.kotlintest.home.view.presenter

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.google.gson.JsonObject
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.Login
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboLoginSource
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.http.Header

/**
 * Created by Administrator on 2017-12-18.
 */
class LoginPresenter : LoginContract.Presenter {
    override fun getLoginAuthenticate(id: String, pw: String, nextUrl: String, context: Context) {
        LoginData?.getLoginAuthenticate("fhl-2","rkdalsrl!",nextUrl)?.enqueue(object : Callback<Login>{
            override fun onFailure(call: Call<Login>?, t: Throwable?) {
                view?.showLoadSuccess()
            }

            override fun onResponse(call: Call<Login>?, response: Response<Login>?) {
                Log.d("Tag","response : "+ response?.raw())
                if(response?.raw()?.message() == "OK"){
                    var login : Login = response.body()
                        adapterModel?.addLoginItem(login)
                        Log.d("Response Body : ",login.toString())
                        view?.showToast(login.ResultMsg)

                }else{
                    Log.d("Tag Error",response?.raw()?.message())
                }
            }

        })
    }
    lateinit override var adapterModel: ViewAdapterContract.LoginModel
    override var view : LoginContract.View? = null
    lateinit override var LoginData: KayboLoginSource

    private fun onClickListener(postion:Int){
        adapterModel.getLoginItem(postion).let {
            view?.showToast(it?.ResultMsg!!)
        }
    }


}