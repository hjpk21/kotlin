package com.kaybo1.dev.kotlintest.home.view.data

/**
 * Created by Administrator on 2017-12-11.
 */
data class DummyList (var name :String,
                      var Id:Int,
                      var url:String)