package com.kaybo1.dev.kotlintest.Channel.adapter.model

import com.kaybo1.dev.kotlintest.Channel.ChannelIdActivity
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList

/**
 * Created by Administrator on 2018-01-25.
 */
interface ChannelInfoListModel {
    var channelInfoItemList : List<ChannelResponse>?
    fun getMainImageUrl() : String
    fun getThumbMainImageUrl() : String


}