package com.kaybo1.dev.kotlintest.postDetailDummy

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.PersistableBundle
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.postDetailDummy.presenter.PostDummyContract
import com.kaybo1.dev.kotlintest.postDetailDummy.presenter.PostDummyPresenter
import kotlinx.android.synthetic.main.activity_postdetail.*
import tech.thdev.base.view.BasePresenterActivity

/**
 * Created by Administrator on 2018-02-27.
 */
class PostDummyActivity : BasePresenterActivity<PostDummyContract.View, PostDummyContract.Presenter>(), PostDummyContract.View {
    override fun updateItem(item: PostDetailResponse) {
        Glide.with(this)
                .load(item.getthumbImageUrl())
                .fitCenter()
                .crossFade()
                .into(postdetail_images)
    }

    override fun onCreatePresenter() = PostDummyPresenter()

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_postdetail)
        setSupportActionBar(toolbar)
        title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        presenter?.postDetailDataSource = PostDetailDataSource


        val postId = intent.getStringExtra("postId")
        presenter?.loadThumbInfo(postId.toInt())
    }

}