package com.kaybo1.dev.kotlintest.PostDetail.adapter.holder

import android.annotation.SuppressLint
import android.content.Context
import android.media.Image
import android.util.Log
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_comments.view.*
import kotlinx.android.synthetic.main.list_post_detail.view.*

/**
 * Created by Administrator on 2018-02-27.
 */
@SuppressLint("LongLogTag")
class CommentsViewHolder(context: Context, parent:ViewGroup?, var onItemClickListener: OnItemClickListener?) : BaseViewHolder<CommentsResponse>(R.layout.list_comments,context,parent){

    override fun bindView(item: CommentsResponse?, position: Int) {
        itemView?.let {
            with(it) {
                Log.d("TAG : [CommentsViewHolder] ","bindView = "+item)
                ImageDownload.loadImage(R.drawable.ic_my_1_pressed,comment_img,item?.member?.getProfileImagUrl())
                comment_name_text.text = item?.member?.nickName
                comment_content_text.text = item?.content

                it.setOnTouchListener { view, motionEvent ->
                    onItemClickListener?.onItemClick(motionEvent, position) ?: false
                }
            }
        }

    }
}