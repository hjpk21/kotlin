package com.kaybo1.dev.kotlintest.models

/**
 * Created by Administrator on 2017-11-27.
 */
enum class ToolbarListType {
    All,
    LeashTrained,
    Small,
    Big,
    Active
}