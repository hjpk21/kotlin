package com.kaybo1.dev.kotlintest.home.view.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.ChannelList


/**
 * Created by Administrator on 2017-12-28.
 */

class ChannelViewAdapter(private val context: Context, private val list:MutableList<ChannelList> = ArrayList()) : RecyclerView.Adapter<ChannelViewAdapter.ChannelViewAdapterHolder>(), ViewAdapterContract.ChannelModel, ViewAdapterContract.ChannelView {
    override fun addChannelItem(item: ChannelList) {
        list.add(item)
    }

    override fun onBindViewHolder(holder: ChannelViewAdapterHolder?, position: Int) {
        holder?.name?.text = getChannelItem(position).name
        holder?.title?.text = getChannelItem(position).title
        Glide.with(context)
                .load(getChannelItem(position).getImageUrl())
                .centerCrop()
                .placeholder(R.drawable.sample_00)
                .into(holder?.image)
    }

    //val itemHomeCartoonList : MutableList<HomeCartoonList> = ArrayList()

    //private fun getItem(position: Int) = list?.get(position)

/*    override fun onBindViewHolder(holder: HomeCartoonViewHolder?, position: Int) {
        holder?.bindView(getItem(position),position)
    }*/

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ChannelViewAdapterHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.list_channelsingle,null)
        val mh = ChannelViewAdapterHolder(v)
        return mh
        //return HomeCartoonViewHolder(viewType, context, parent!!)
    }

    override fun getItemCount() = list.size

    override fun reload() {
        notifyDataSetChanged()
    }

    override fun clear() {
        list.clear()
    }

    private fun getChannelItem(position: Int) = list.get(position)

    inner class ChannelViewAdapterHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name : TextView = view.findViewById(R.id.channel_name)
        val image : ImageView = view.findViewById(R.id.channel_image)
        val title : TextView = view.findViewById(R.id.channel_title)
    }

}