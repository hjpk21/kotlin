package com.kaybo1.dev.kotlintest.Kcoin.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.MotionEvent
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.Kcoin.adapter.holder.DummyLoginViewHolder
import com.kaybo1.dev.kotlintest.Kcoin.adapter.model.DummyLoginModel
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.home.view.data.DummyList
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-26.
 */
@SuppressLint("LongLogTag")
class DummyLoginAdapter(private val context: Context, item:ArrayList<DummyList>?) : RecyclerView.Adapter<BaseViewHolder<DummyList>>(), DummyLoginModel {
    override var dummyList: ArrayList<DummyList>? = item

    override var onItemTouchListener: OnItemClickListener? = null


    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                Log.d("TAG : [DummyLoginAdapter]","onItemClick")
                return onTouch(motionEvent,postion)
            }
        }
    }

    override fun onBindViewHolder(holder: BaseViewHolder<DummyList>?, position: Int) {
        Log.d("TAG : [DummyLoginAdapter] ","onBindViewHolder : "+position)
        holder?.bindView(getItem(position),position)
    }

    override fun getItemCount(): Int {
        return dummyList?.size ?:0
    }

    private fun getItem(position: Int) = dummyList?.get(position)

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<DummyList> {
        return DummyLoginViewHolder(context,parent,onItemTouchListener)
    }

}