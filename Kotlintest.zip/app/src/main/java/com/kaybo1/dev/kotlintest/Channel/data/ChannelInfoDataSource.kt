package com.kaybo1.dev.kotlintest.Channel.data

import com.kaybo1.dev.kotlintest.BuildConfig
import com.kaybo1.dev.kotlintest.base.util.createRetrofit
import com.kaybo1.dev.kotlintest.network.ChannelInfoServiceInterface

/**
 * Created by Administrator on 2018-01-18.
 */
object ChannelInfoDataSource {
    val KAYBO_URL = BuildConfig.KAYBO_REAL_URL

    private val channelInfoServiceInterface : ChannelInfoServiceInterface

    init {
        channelInfoServiceInterface = createRetrofit(ChannelInfoServiceInterface::class.java, KAYBO_URL)
    }

    fun getChannelInfo(channelId : Int) = channelInfoServiceInterface.getChannelInfo(channelId)

    fun getChannelResponse(channelId: Int) = channelInfoServiceInterface.getChannelResponse(channelId)

    fun getPostLIstResponse(boardId : Int,categoryId:Int,pageable : Int,size :Int) = channelInfoServiceInterface.getPostLIstResponse(boardId,categoryId,pageable,size)


}