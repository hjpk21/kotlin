package com.kaybo1.dev.kotlintest.home.view.presenter

import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.ChannelList
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.models.ToolbarListType

/**
 * Created by Administrator on 2017-11-28.
 */
interface SampleContract {
    interface View {
        /**
         * 로딩 완료
         */
        fun showLoadSuccess()

        /**
         * 로딩 실패
         */
        fun showLoadFail()

        fun showLoadFailMessage(message: String)

        fun showLink(linkUrl : String)

    }
    interface Presenter{
        var view: View?

        var kayboData : KayboDataSource?

        var adapterModel : ViewAdapterContract.Model?

        var adapterView : ViewAdapterContract.View?

        var adapterBannerModel : ViewAdapterContract.BannerModel?

        var adapterBannerView : ViewAdapterContract.BannerView?

        var adapterChannelModel : ViewAdapterContract.ChannelModel?

        var adapterChannelView : ViewAdapterContract.ChannelView?

        var adapterNoticeModel : ViewAdapterContract.NoticeModel?

        var adapterNoticeView : ViewAdapterContract.NoticeView?

        var adapterShortCutModel : ViewAdapterContract.ShortCutModel?

        var adapterShortCutView : ViewAdapterContract.ShortCutView?

        var adapterHomeCartoonModel : ViewAdapterContract.HomeCartoonModel?

        var adapterHomeCartoonView : ViewAdapterContract.HomeCartoonView?

        fun getChannelListSample(listType: ToolbarListType)

        fun getAllHomeList()
    }
}