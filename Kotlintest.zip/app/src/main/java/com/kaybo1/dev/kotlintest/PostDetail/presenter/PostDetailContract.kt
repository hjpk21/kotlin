package com.kaybo1.dev.kotlintest.PostDetail.presenter

import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.CommentsPagerModel
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostContentsPagerModel
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostDetailReponseModel
import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import tech.thdev.base.presenter.BasePresenter
import tech.thdev.base.presenter.BaseView

/**
 * Created by Administrator on 2018-02-19.
 */
interface PostDetailContract {
    interface View : BaseView {
        fun updateItem(item : PostDetailResponse)
        fun commentItem(item : List<CommentsResponse>)
    }
    interface Presenter : BasePresenter<View> {
        var postDetailDataSource : PostDetailDataSource?

        var commentsPagerModel: CommentsPagerModel?

        var postDetailResponseModel : PostDetailReponseModel?

        var postContentsPagerModel : PostContentsPagerModel?

        fun loadPostDetail(postId : Int)

        fun loadComments(postId: Int)

    }
}