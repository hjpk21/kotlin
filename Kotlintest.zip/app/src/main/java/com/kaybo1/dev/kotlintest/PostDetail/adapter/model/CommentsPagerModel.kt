package com.kaybo1.dev.kotlintest.PostDetail.adapter.model

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-19.
 */
interface CommentsPagerModel {
    var commentsResponse : List<CommentsResponse>?
    val onItemTouchListener : OnItemClickListener?
    fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)

}