package com.kaybo1.dev.kotlintest.Channel.data.model

/**
 * Created by Administrator on 2018-01-23.
 */
data class Service (val serviceId : String,
                    val name : String,
                    val companyName : String,
                    val description : String,
                    val thumbImage : String,
                    val mainImage : String,
                    val playUrl : String,
                    val status : String,
                    val releaseDate : String)