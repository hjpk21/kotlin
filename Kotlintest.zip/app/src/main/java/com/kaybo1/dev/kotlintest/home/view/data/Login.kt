package com.kaybo1.dev.kotlintest.home.view.data

import java.util.*

/**
 * Created by Administrator on 2017-12-18.
 */
data class Login (val UserUID : String,
                  val UserID : String,
                  val UserName : String,
                  val Gender : String,
                  val Email : String,
                  val Country : String,
                  val NickName : String,
                  val ProfileImg : String,
                  val UserAuth : String,
                  val Result : String,
                  val ResultMsg : String,
                  val nextUrl : String
                 ){


}