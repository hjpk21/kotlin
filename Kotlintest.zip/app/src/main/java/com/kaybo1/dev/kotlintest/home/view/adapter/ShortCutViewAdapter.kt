package com.kaybo1.dev.kotlintest.home.view.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.HomeCartoonList
import com.kaybo1.dev.kotlintest.home.view.data.ShortCutList
import com.kaybo1.dev.kotlintest.network.ImageDownload

/**
 * Created by Administrator on 2017-12-11.
 */


class ShortCutViewAdapter(private val context: Context, private val list:MutableList<ShortCutList> = ArrayList()) : RecyclerView.Adapter<ShortCutViewAdapter.ShortCutViewHolder>(),ViewAdapterContract.ShortCutView,ViewAdapterContract.ShortCutModel {
    override fun addShortCutItem(item: ShortCutList) {
        list.add(item)
    }

    override fun clear() {
        list.clear()
    }

    override fun onBindViewHolder(holder: ShortCutViewHolder?, position: Int) {
        //Log.d("ShortCutViewAdapter",position.toString())
        ImageDownload.loadImage(R.drawable.loading,holder?.image!!,getShortCutItem(position).getShortCutImage())
        /*Glide.with(context)
                .load(getShortCutItem(position).getShortCutImage())
                .centerCrop()
                .placeholder(R.drawable.sample_00)
                .into(holder?.image)*/
    }

    //val itemHomeCartoonList : MutableList<HomeCartoonList> = ArrayList()


/*    override fun onBindViewHolder(holder: SampleView2Holder?, position: Int) {
        holder?.bindView(getItem(position),position)
    }*/

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ShortCutViewHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.list_single,null)
        val mh = ShortCutViewHolder(v)
        return mh
        //return SampleView2Holder(viewType, context, parent!!)
    }

    override fun getItemCount() = list.size

    override fun reload() {
        notifyDataSetChanged()
    }

    private fun getShortCutItem(position: Int) = list.get(position)

    inner class ShortCutViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val image : ImageView = view.findViewById(R.id.image)
    }

}