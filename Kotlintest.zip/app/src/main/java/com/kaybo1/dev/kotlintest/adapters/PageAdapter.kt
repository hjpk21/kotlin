package com.kaybo1.dev.kotlintest.adapters

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.util.Log
import com.kaybo1.dev.kotlintest.fragmemts.*
import com.kaybo1.dev.kotlintest.models.CouponToolbarListType
import com.kaybo1.dev.kotlintest.models.ToolbarListType

/**
 * Created by Administrator on 2017-11-27.
 */
class PageAdapter (fm:FragmentManager, private val context:Context) : FragmentPagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        when (position) {
            0 -> {
                Log.d("TAG : [PageAdapter]","All : "+position.toString())
                return SampleFragment.newInstance(ToolbarListType.All,context)
            }
            1 -> {
                //coupon
                Log.d("TAG : [PageAdapter]","Active : "+position.toString())
                return DummyCouponFragment()
                //return CouponFragment.newInstance(CouponToolbarListType.PcGame,context)
            }
            2 -> {
                Log.d("TAG : [PageAdapter]","Small : "+position.toString())
                //channel
                return TestFragment.getInstance()
            }
            3 -> {
                Log.d("TAG : [PageAdapter]","LeashTrained : "+position.toString())
                //kcoin
                return KcoinFragment()
            }
            4 -> {
                Log.d("TAG : [PageAdapter]","Big : "+position.toString())
                //mypage
                return MyPageFragment()
            }
        }
        return FirstFragment.newInstance("first","second")
    }

    override fun getCount(): Int {
        return 5
    }

}