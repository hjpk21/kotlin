package com.kaybo1.dev.kotlintest.home.view.data

import android.util.Log
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2017-11-28.
 */
data class BannerList (val homeBannerId : String,
                       var imageUrl : String,
                       val linkUrl : String,
                       val createData : Any) {

    fun getImage() : String {

        if(imageUrl != null) {
            if (imageUrl.startsWith("http")) {
                //Log.d(" Banner thumbimage",imageUrl)
                imageUrl
            } else {
                imageUrl = BuildConfig.KAYBO_REAL_URL+"$imageUrl"
                //Log.d(" Banner thumbimage2",imageUrl)
            }
        }else{

        }

        return imageUrl
    }
}