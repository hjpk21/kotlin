package com.kaybo1.dev.kotlintest.network

import com.google.gson.JsonObject
import com.kaybo1.dev.kotlintest.home.view.data.Login
import retrofit2.Call
import retrofit2.http.*

/**
 * Created by Administrator on 2017-12-18.
 */
interface LoginSeviceInterface {
    @Headers("Content-Type : application/json")
    @POST("login/kaybo/process2")
    fun authenticate(@Query("id") id: String, @Query("password") pw:String, @Query("nextUrl") nextUrl:String) : Call<Login>


}