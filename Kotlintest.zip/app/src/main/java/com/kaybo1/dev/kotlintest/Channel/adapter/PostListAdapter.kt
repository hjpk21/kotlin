package com.kaybo1.dev.kotlintest.Channel.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.MotionEvent
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.Channel.adapter.holder.PostListViewHolder
import com.kaybo1.dev.kotlintest.Channel.adapter.model.ChannelInfoListModel
import com.kaybo1.dev.kotlintest.Channel.adapter.model.PostListModel
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.Channel.presenter.ChannelIdContract
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-07.
 */
@SuppressLint("LongLogTag")
class PostListAdapter(private val context: Context,item:List<PostList>?) : RecyclerView.Adapter<BaseViewHolder<PostList>>(), PostListModel {
    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                //Log.d("TAG : [PostListAdapter]","onItemClick")
                return onTouch(motionEvent,postion)
            }
        }
    }

    override var postList: List<PostList>? = item


    override fun getItemCount(): Int {
        return postList?.size ?:0
    }

    private fun getItem(postion: Int) = postList?.get(postion)



    override fun onBindViewHolder(holder: BaseViewHolder<PostList>?, position: Int) {
        //Log.d("TAG : [PostListAdapter] ","onBindViewHolder : "+position)
        holder?.bindView(getItem(position),position)
    }


    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<PostList> {
        //Log.d("TAG : [PostListAdapter] ","onCreateViewHolder : "+onItemTouchListener)
         return PostListViewHolder(context,parent,onItemTouchListener)
    }
}