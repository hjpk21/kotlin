package com.kaybo1.dev.kotlintest.network

import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * Created by Administrator on 2018-01-18.
 */
interface ChannelInfoServiceInterface {
    @GET("api/community/common/channelInfo/{channelId}")
    fun getChannelInfo(@Path("channelId") channelId: Int) : Call<ChannelInfo>

    @GET("api/community/channels/{channelId}/boards")
    fun getChannelResponse(@Path("channelId") channelId: Int) : Call<List<ChannelResponse>>

    @GET("api/community/postList/{boardId}")
    fun getPostLIstResponse(@Path("boardId") boardId : Int,@Query("categoryId") categoryId : Int,@Query("page") pageable : Int,@Query("size") size :Int) : Call<List<PostList>>

}