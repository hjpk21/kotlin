package com.kaybo1.dev.kotlintest.Kcoin.data.model

/**
 * Created by Administrator on 2018-02-26.
 */
data class Balance (val retcode : String,
                    val cashreal : String,
                    val cashbouns : String,
                    val retmsg : String,
                    val userno : String)