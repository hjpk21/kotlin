package com.kaybo1.dev.kotlintest.Channel.data.model

import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-01-23.
 */
data class Channel (val channelId :String,
                    val serviceId : String,
                    val name : String,
                    val mainImage : String,
                    val thumbImage : String,
                    val createDate : String,
                    val channelDetail : ChannelDetail,
                    val service : Service,
                    val new : Boolean,
                    val hot : Boolean){
    fun getmainImageUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val headerImage : String = url + "$mainImage"
        return headerImage
    }
    fun getthumbImageUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val thumbImage : String = url + "$thumbImage"
        return thumbImage
    }
}