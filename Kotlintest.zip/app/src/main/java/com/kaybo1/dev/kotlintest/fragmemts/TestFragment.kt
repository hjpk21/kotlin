package com.kaybo1.dev.kotlintest.fragmemts

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.kaybo1.dev.kotlintest.MainActivity
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.util.createChannelInfoIntent
import com.kaybo1.dev.kotlintest.community.adapter.adapter.CommunityListAdapter
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.CommunityDataSource
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityContract
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityPresenter
import kotlinx.android.synthetic.main.fragment_community.*

@SuppressLint("ValidFragment")
/**
 * Created by Administrator on 2018-01-10.
 */
class TestFragment : Fragment(), CommunityContract.View{
    override fun showChannelDetail(channelId: String) {
        startActivity(context.createChannelInfoIntent(channelId))
    }

    private val fab by lazy {
        activity.findViewById<FloatingActionButton>(R.id.fab) as FloatingActionButton
    }

    override fun showLoadSuccess() {
        Toast.makeText(context, "Load success", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFail() {
        Log.d("TAG : [TestFragment]","showLoadFail")
        Toast.makeText(context, "Load Fail", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFailMessage(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        Log.e("TAG", "Exception : " + message)
    }

    companion object {
        fun getInstance() = TestFragment()

        /*fun newInstance(context:Context) : TestFragment {
            val fragment = TestFragment(context)
            return fragment
        }*/
    }
    private var adapter : CommunityListAdapter?  = null
    private var presenter : CommunityContract.Presenter?  = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }
    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View? {
       val rootview : View? = inflater?.inflate(R.layout.fragment_community,container,false)
        rootview?.findViewById<View>(R.id.image)?.setOnClickListener {
            Log.d("Clicked","Clicked")
        }
        return rootview
    }



    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        presenter = CommunityPresenter()
        presenter?.view = this

        adapter = CommunityListAdapter(context)

        presenter?.kayboData = CommunityDataSource

        presenter?.adapterAllListModel = adapter
        presenter?.adapterAllListView = adapter

        recycler_image.adapter = adapter

        fab.setOnClickListener {
            presenter?.getCommunityLists()
        }

        presenter?.getCommunityLists()

    }
}