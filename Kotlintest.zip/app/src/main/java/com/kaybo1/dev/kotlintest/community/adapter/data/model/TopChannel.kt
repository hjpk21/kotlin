package com.kaybo1.dev.kotlintest.community.adapter.data.model

import android.util.Log
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2017-12-28.
 */
data class TopChannel(@SerializedName("thumbImageUrl")
                          @Expose
                          var thumbImageUrl : String,
                          @SerializedName("channelId")
                            @Expose
                            val channelId : String,
                            @SerializedName("title")
                            @Expose
                            val title :String,
                            @SerializedName("isNew")
                            @Expose
                             val isNew : Boolean){
    fun getImage() : String {

        if(thumbImageUrl != null) {
            if (thumbImageUrl.startsWith("http")) {
                Log.d(" Banner thumbimage",thumbImageUrl)
                thumbImageUrl
            } else {
                thumbImageUrl = BuildConfig.KAYBO_REAL_URL+"$thumbImageUrl"
                Log.d(" Banner thumbimage2",thumbImageUrl)
            }
        }else{

        }

        return thumbImageUrl
    }

}