package com.kaybo1.dev.kotlintest.fragmemts

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.view.ViewPager
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.util.createKcoinIntent
import kotlinx.android.synthetic.main.fragment_kcoin.*
import tech.thdev.base.view.BaseFragment

/**
 * Created by Administrator on 2018-02-27.
 */
class KcoinFragment : BaseFragment(){
    override fun getLayout(): Int = R.layout.fragment_kcoin

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        startActivity(context.createKcoinIntent("SampleToken"))
    }

}