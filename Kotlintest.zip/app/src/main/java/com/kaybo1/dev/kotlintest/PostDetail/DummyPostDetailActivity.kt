package com.kaybo1.dev.kotlintest.PostDetail

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.kaybo1.dev.kotlintest.PostDetail.adapter.PostDetailResponseAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.presenter.DummyContract
import com.kaybo1.dev.kotlintest.PostDetail.presenter.DummyPresenter
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailContract
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.activity_postdetail.*

/**
 * Created by Administrator on 2018-03-02.
 */
@SuppressLint("LongLogTag")
class DummyPostDetailActivity : AppCompatActivity(),DummyContract.View{
    override fun updateItem(item: PostDetailResponse) {
        Log.d("TAG : [DummyPostDetailActivity] ","updateItem = "+item)
        ImageDownload.loadImage(R.drawable.loading,postdetail_images,item.member.getProfileImagUrl())
        postdetail_text.text = item.member.nickName
    }

    override fun commentItem(item: List<CommentsResponse>) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private var mSectionsAdapter : PostDetailResponseAdapter? = null
    private var mViewPager : ViewPager? = null
    private var presenter : DummyPresenter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("TAG : [DummyPostDetailActivity] ","onCreate")
        setContentView(R.layout.activity_postdetail)
        var postId = intent.getStringExtra("postId")
        onCreateView(postId.toInt())

        mSectionsAdapter = PostDetailResponseAdapter(supportFragmentManager,applicationContext,postId.toInt())
        mViewPager = postdetail_container
        mViewPager!!.adapter = mSectionsAdapter

    }
    private fun onCreateView(postId : Int){
        presenter?.postDetailDataSource
        Log.d("TAG : [DummyPostDetailActivity] ","onCreateView")
        presenter?.loadPostDetail(postId)
    }

}