package com.kaybo1.dev.kotlintest.base.util

import android.content.Context
import android.preference.PreferenceManager
import okhttp3.Credentials
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException

/**
 * Created by Administrator on 2017-11-30.
 */
fun <T> createRetrofit(cls : Class<T>, baseUrl : String): T {
    val retrofit : Retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            //.client(createOkHttpClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    return retrofit.create(cls)
}

private fun createOkHttpClient(): OkHttpClient {
    val builder: OkHttpClient.Builder = OkHttpClient.Builder()

    val interceptor = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

    builder.addInterceptor(interceptor)
    return builder.build()
}

