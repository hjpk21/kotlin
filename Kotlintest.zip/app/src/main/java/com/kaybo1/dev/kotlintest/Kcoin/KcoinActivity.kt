package com.kaybo1.dev.kotlintest.Kcoin

import android.annotation.SuppressLint
import android.app.Fragment
import android.app.PendingIntent.getActivity
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.MenuItem
import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Kcoin.adapter.DummyLoginAdapter
import com.kaybo1.dev.kotlintest.Kcoin.data.KcoinDataSource
import com.kaybo1.dev.kotlintest.Kcoin.data.model.Balance
import com.kaybo1.dev.kotlintest.Kcoin.presenter.KcoinContract
import com.kaybo1.dev.kotlintest.Kcoin.presenter.KcoinPresenter
import com.kaybo1.dev.kotlintest.LoginActivity
import com.kaybo1.dev.kotlintest.MainActivity
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.fragmemts.KcoinFragment
import com.kaybo1.dev.kotlintest.fragmemts.SampleFragment
import com.kaybo1.dev.kotlintest.home.view.data.DummyList
import com.kaybo1.dev.kotlintest.home.view.data.DummyListFactory
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.models.ToolbarListType
import kotlinx.android.synthetic.main.activity_kcoin.*
import tech.thdev.base.view.BasePresenterActivity

/**
 * Created by Administrator on 2018-02-26.
 */
@SuppressLint("LongLogTag")
class KcoinActivity : BasePresenterActivity<KcoinContract.View, KcoinContract.Presenter>() , KcoinContract.View {

    override fun changePage(id: Int) {
        Log.d("TAG : [KcoinActivity] ","changePage = "+id)
        //그전에 페이스북,구글,카이보 에 따라 세션작업을 한후 넘겨주는곳
        onBackPressed()
        //startActivity(redirectIntent(token))
    }

    override fun dummyLogin(item: ArrayList<DummyList>) {
        title = "Login Page"
        dummyLoginAdapter = DummyLoginAdapter(applicationContext,item)
        presenter?.dummyLoginModel = dummyLoginAdapter
        recycler_login.adapter = dummyLoginAdapter
        recycler_login.layoutManager = LinearLayoutManager(applicationContext,LinearLayoutManager.VERTICAL,false)
        isLoading = false
    }

    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                Log.d("TAG : [KcoinActivity]","onItemClick : "+postion)
                return onTouch(motionEvent,postion)
            }
        }
    }
    var isLoading = true
    private var token = ""
    private var dummyLoginAdapter : DummyLoginAdapter? = null

    override fun updateItem(balance: Balance) {

    }
    private var dummyLists : DummyListFactory = DummyListFactory()

    override fun onCreatePresenter(): KcoinContract.Presenter? = KcoinPresenter()


    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kcoin)

        setSupportActionBar(toolbar)
        title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        presenter?.kcoinDataSource = KcoinDataSource

        token = intent.getStringExtra("token")

        presenter?.loadKcoinBalance()

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId){
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun redirectIntent(token : String) : Intent {
        val intent = Intent(this,MainActivity::class.java)
        intent.putExtra("Page",token)
        return intent
    }





}
