package com.kaybo1.dev.kotlintest.Channel.data.model

/**
 * Created by Administrator on 2018-01-23.
 */
data class Detail (val totalPostCount : String,
                   val totalCommentCount : String)