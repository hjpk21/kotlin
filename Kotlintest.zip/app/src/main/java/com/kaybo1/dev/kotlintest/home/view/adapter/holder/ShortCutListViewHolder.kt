package com.kaybo1.dev.kotlintest.home.view.adapter.holder

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.HomeCartoonViewAdapter
import com.kaybo1.dev.kotlintest.home.view.data.HomeCartoonList
import com.kaybo1.dev.kotlintest.home.view.data.ShortCutList
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_single.view.*

/**
 * Created by Administrator on 2017-12-11.
 */

class ShortCutListViewHolder(resoruce: Int, context: Context, parent: ViewGroup) :
        RecyclerView.ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_single,parent,false)) {

    fun bindView(item: ShortCutList?, position:Int){
        itemView?.let {
            with(it){
                ImageDownload.loadImage(R.drawable.loading, image, item?.getShortCutImage())
            }
        }

    }


}