package com.kaybo1.dev.kotlintest.PostDetail.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.PostDetail.adapter.holder.PostContentViewHolder
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostContentsPagerModel
import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder

/**
 * Created by Administrator on 2018-03-02.
 */
class PostContentsPagerAdapter(private val context: Context, item:List<PostContents>) : RecyclerView.Adapter<BaseViewHolder<PostContents>>(), PostContentsPagerModel {
    override fun onBindViewHolder(holder: BaseViewHolder<PostContents>?, position: Int) {
        holder?.bindView(getItem(position),position)
    }

    override fun getItemCount(): Int = postContents?.size ?: 0

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<PostContents> {
        return PostContentViewHolder(context,parent)
    }

    override var postContents: List<PostContents>? = item

    private fun getItem(postion : Int) = postContents?.get(postion)
}