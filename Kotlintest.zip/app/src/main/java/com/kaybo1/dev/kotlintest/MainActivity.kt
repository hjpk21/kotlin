package com.kaybo1.dev.kotlintest


import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.FragmentTransaction
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.util.Log

import com.kaybo1.dev.kotlintest.adapters.PageAdapter
import com.kaybo1.dev.kotlintest.fragmemts.FirstFragment


import com.kaybo1.dev.kotlintest.home.view.presenter.LoginContract
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity(),LoginContract,SampleContract.View {
    override fun showLink(linkUrl: String) {
        Log.d("TAG : [MainActivity] ","showLink "+linkUrl)
    }

    override fun showLoadSuccess() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showLoadFail() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showLoadFailMessage(message: String) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private var notificationManager : NotificationManager? =null


    override fun refreshFragment() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun replaceFragment(fragmentId: Int)  {
        val intent = Intent(this,LoginActivity::class.java)
        startActivity(intent)
    }

    private var firstFragment : FirstFragment? = null
    private var mSectionsPagerAdaper: PagerAdapter? = null
    private var mViewPager: ViewPager? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //setDefaultFragment()
        //android kotlin extensions
        setSupportActionBar(toolbar)

        mSectionsPagerAdaper = PageAdapter(supportFragmentManager, this)

        mViewPager = container
        mViewPager!!.adapter = mSectionsPagerAdaper

        tabs.setupWithViewPager(mViewPager)

        tabs.getTabAt(0)!!.setIcon(R.drawable.bg_gnb_home_selected)
        tabs.getTabAt(1)!!.setIcon(R.drawable.bg_gnb_coupon)
        tabs.getTabAt(2)!!.setIcon(R.drawable.bg_gnb_community)
        tabs.getTabAt(3)!!.setIcon(R.drawable.bg_gnb_coin)
        tabs.getTabAt(4)!!.setIcon(R.drawable.bg_gnb_my)
        //API연동
        val notification = Notification.Builder(this@MainActivity)
                .setSmallIcon(R.drawable.navigation_empty_icon)
                .setContentTitle("KAYBO notification TEST")
                .setContentText("Firebase message")

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        //새로운글이 올라오거나 시간별로 알람
        notificationManager.notify(0,notification.build())


    }
    fun setDefaultFragment() {
        supportFragmentManager.beginTransaction().replace(R.id.container, firstFragment).commit()
        //transaction.add(R.id.container, firstFragment)
    }
    fun createNotificationChannel(name:String,description:String) {
        val importance = NotificationManager.IMPORTANCE_LOW




    }

}
