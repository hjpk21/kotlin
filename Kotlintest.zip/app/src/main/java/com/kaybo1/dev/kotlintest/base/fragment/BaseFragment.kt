package com.kaybo1.dev.kotlintest.base.fragment

import android.view.View

/**
 * Created by Administrator on 2017-12-13.
 */
interface BaseFragment {
        companion object {
            fun getInsetance(){

            }
        }












}