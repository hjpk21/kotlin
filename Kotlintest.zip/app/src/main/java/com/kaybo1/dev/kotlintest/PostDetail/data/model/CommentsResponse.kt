package com.kaybo1.dev.kotlintest.PostDetail.data.model

import com.kaybo1.dev.kotlintest.PostDetail.data.Member

/**
 * Created by Administrator on 2018-02-28.
 */
data class CommentsResponse (val commentId : String,
                             val content : String,
                             val postId : String,
                             val memberId :String,
                             val commmentDate : String,
                             val parentCommentId :String,
                             val childCommentList :String,
                             val childCommentCount : String,
                             val commentDetail : CommentDetail,
                             val member : Member)