package com.kaybo1.dev.kotlintest.home.view.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.util.Log

import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.home.view.adapter.holder.HomeCartoonViewHolder
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract

import com.kaybo1.dev.kotlintest.home.view.data.HomeCartoonList

import com.kaybo1.dev.kotlintest.listener.OnItemClickListener



/**
 * Created by Administrator on 2017-12-05.
 */
@SuppressLint("LongLogTag")

class HomeCartoonViewAdapter(private val context: Context, private val list:MutableList<HomeCartoonList> = ArrayList(),val onItemClickListenered: OnItemClickListener?) : /*RecyclerView.Adapter<HomeCartoonViewHolder>()*/RecyclerView.Adapter<BaseViewHolder<HomeCartoonList>>(), ViewAdapterContract.HomeCartoonModel, ViewAdapterContract.HomeCartoonView {
    override fun onBindViewHolder(holder: BaseViewHolder<HomeCartoonList>?, position: Int) {
        holder?.bindView(getHomeCartoonItem(position),position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<HomeCartoonList> = HomeCartoonViewHolder(context,parent,onItemClickListenered)


    override fun showLinkUrl(linkUrl: String) {
        Log.d("TAG : [HomeCartoonViewAdapter]","ViewAdapterContract.HomeCartoonView")
        var i = Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl))
        context.startActivity(i)
    }

    override fun getItem(position: Int): HomeCartoonList = list[position]

    /*override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): com.kaybo1.dev.kotlintest.home.view.adapter.holder.HomeCartoonViewHolder
            = com.kaybo1.dev.kotlintest.home.view.adapter.holder.HomeCartoonViewHolder(viewType,context,parent,onItemTouchListener)

    override fun onBindViewHolder(holder: com.kaybo1.dev.kotlintest.home.view.adapter.holder.HomeCartoonViewHolder?, position: Int) {
        holder?.bindView(getHomeCartoonItem(position),position)
    }*/

    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                Log.d("TAG : [HomeCatoonViewAdapter] ","setOnItemTouchListener")
                return onTouch(motionEvent,postion)
            }
        }
    }

    override fun addHomeCartoonItem(item: HomeCartoonList) {
        list.add(item)
    }


    /*override fun onBindViewHolder(holder: HomeCartoonViewHolder?, position: Int) {
       ImageDownload.loadImage(R.drawable.loading,holder?.image!!,getHomeCartoonItem(position).getHomeCartoonImage())
        *//* Glide.with(context)
                .load(getHomeCartoonItem(position).getHomeCartoonImage())
                .centerCrop()
                .placeholder(R.drawable.sample_00)
                .into(holder?.image)*//*
    }

    //val itemHomeCartoonList : MutableList<HomeCartoonList> = ArrayList()

    //private fun getItem(position: Int) = list?.get(position)

*//*    override fun onBindViewHolder(holder: HomeCartoonViewHolder?, position: Int) {
        holder?.bindView(getItem(position),position)
    }*//*

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): HomeCartoonViewHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.list_single,null)
        val mh = HomeCartoonViewHolder(v)
        return mh
        //return HomeCartoonViewHolder(viewType, context, parent!!)
    }*/

    override fun getItemCount() = list.size

    override fun reload() {
        notifyDataSetChanged()
    }

    override fun clear() {
        list.clear()
    }

    private fun getHomeCartoonItem(position: Int) = list.get(position)

    inner class HomeCartoonViewHolder(view:View) : RecyclerView.ViewHolder(view) {
        val image : ImageView = view.findViewById(R.id.image)
    }

}