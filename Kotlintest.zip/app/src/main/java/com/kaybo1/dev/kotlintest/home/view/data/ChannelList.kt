package com.kaybo1.dev.kotlintest.home.view.data

import android.util.Log
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2017-11-28.
 */
data class ChannelList (val name : String,
                        val postId : String,
                        val type : String,
                        val channelId : String,
                        val content : String,
                        var thumbImageUrl : String,
                        val title : String) {
    fun getImageUrl() : String{
        if(thumbImageUrl != null) {
            if (thumbImageUrl.startsWith("http")) {
                //Log.d("Channel thumbimage",thumbImageUrl)
                thumbImageUrl
            } else {

                thumbImageUrl = BuildConfig.KAYBO_REAL_URL+"$thumbImageUrl"
                //Log.d("Channel thumbimage2",thumbImageUrl)
            }
        }else{

        }

        return thumbImageUrl
    }


}