package com.kaybo1.dev.kotlintest.PostDetail.data

import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-02-19.
 */
data class PostDetailResponse (val postId : String,
                               val boardId : String,
                               val categoryId : String,
                               val memberId : String,
                               val title : String,
                               var thumbImage : String,
                               val postDate :String,
                               val postDetail: PostDetail,
                               val postContents : List<PostContents>,
                               val member: Member
                               ){
    fun getthumbImageUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val thumbImage : String = url + "$thumbImage"

        return thumbImage
    }
}