package com.kaybo1.dev.kotlintest.PostDetail.data

/**
 * Created by Administrator on 2018-02-19.
 */
data class PostDetail (val postId :String,
                       val commentCount : String,
                       val likeCount : String,
                       val shareCount : String,
                       val scrapCount : String,
                       val modifyDate : String,
                       val isMyPost : Boolean,
                       val isSharedPost : Boolean,
                       val isLikePost : Boolean,
                       val isScrapPost : Boolean)