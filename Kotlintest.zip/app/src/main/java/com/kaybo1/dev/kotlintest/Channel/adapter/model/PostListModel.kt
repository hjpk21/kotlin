package com.kaybo1.dev.kotlintest.Channel.adapter.model

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-08.
 */
interface PostListModel {
        var postList : List<PostList>?
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)



}