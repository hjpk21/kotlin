package com.kaybo1.dev.kotlintest.home.view.presenter

import android.content.Context
import android.content.Intent
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.Login
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboLoginSource
import retrofit2.http.Header
import java.io.Serializable

/**
 * Created by Administrator on 2017-12-13.
 */
interface LoginContract : Serializable {
    fun replaceFragment(fragmentId : Int)
    fun refreshFragment()
    interface View {
        fun showToast(title:String)
        fun showLoadSuccess()
    }
    interface Presenter {
        var view : View?
        var LoginData : KayboLoginSource
        fun getLoginAuthenticate(id:String,pw:String,nextUrl:String,context: Context)
        var adapterModel : ViewAdapterContract.LoginModel
    }

}
