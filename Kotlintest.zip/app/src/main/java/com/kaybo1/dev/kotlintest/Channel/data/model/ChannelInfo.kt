package com.kaybo1.dev.kotlintest.Channel.data.model

import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-01-18.
 */
data class ChannelInfo(val channelName : String,
                       val channelId : String,
                       val headerImageUrl : String,
                       val thumbMainImageUrl : String,
                       val playUrl : String,
                       val rank : String,
                       val favoriteCount : String,
                       val totalCommentCount : String,
                       val totalPostCount : String,
                       val isFavorite : Boolean) {
    fun getheaderImageUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val headerImage : String = url + "$headerImageUrl"
        return headerImage
    }
    fun getthumbImageUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val thumbImage : String = url + "$thumbMainImageUrl"
        return thumbImage
    }
}