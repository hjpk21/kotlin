package com.kaybo1.dev.kotlintest.Coupon.adapter

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.kaybo1.dev.kotlintest.fragmemts.CouponFragment
import com.kaybo1.dev.kotlintest.fragmemts.DummyCouponFragment

/**
 * Created by Administrator on 2018-02-28.
 */
class CouponFragmentPagerAdapter(private val context: Context , fm:FragmentManager) : FragmentPagerAdapter(fm){
    override fun getItem(position: Int): Fragment {
        when(position){
            0 -> return CouponFragment.couponInstanse()
            1 -> return CouponFragment.couponInstanse()
            2 -> return CouponFragment.couponInstanse()
        }
        return CouponFragment.couponInstanse()
    }

    override fun getCount(): Int {
        return 3
    }

}