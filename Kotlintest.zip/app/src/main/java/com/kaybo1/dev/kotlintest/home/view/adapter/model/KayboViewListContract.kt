package com.kaybo1.dev.kotlintest.home.view.adapter.model

import android.support.v7.widget.RecyclerView
import android.support.v7.widget.RecyclerView.ViewHolder


/**
 * Created by Administrator on 2017-12-04.
 */
interface KayboViewListContract {
    interface HomeList {
        fun bannerList()
        fun shortCutList()
        fun channelList()
        fun noticeList()
        fun homeCartoonList()
    }
}