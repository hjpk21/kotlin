package com.kaybo1.dev.kotlintest.home.view.adapter.holder

import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.ChannelAdapter
import com.kaybo1.dev.kotlintest.home.view.data.ChannelList
import com.kaybo1.dev.kotlintest.home.view.data.HomeResponse
import com.kaybo1.dev.kotlintest.home.view.data.Info
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.home.view.presenter.SamplePresenter
import com.kaybo1.dev.kotlintest.models.ToolbarListType
import kotlinx.android.synthetic.main.list_item.view.*

/**
 * Created by Administrator on 2017-11-28.
 */
class SampleViewHolder(resoruce: Int, context: Context,parent:ViewGroup) :
        RecyclerView.ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item,parent,false))  {

    private var presenter : SampleContract.Presenter? = null
    private var channelAdapter : ChannelAdapter? = null
    private var dataList : ArrayList<ChannelList> ? = null

    fun beginBindView(){

    }


    fun bindView(item:HomeResponse?,position:Int){
       itemView?.let {
           with(it){
               Log.d("SampleViewHolder","bindView")
               itemTitle.text = item?.info?.recommendTitle
               dataList = item?.channelList
               presenter = SamplePresenter()
               channelAdapter = ChannelAdapter(context)
               presenter?.kayboData = KayboDataSource
               presenter?.adapterChannelModel = channelAdapter
               presenter?.adapterChannelView = channelAdapter
               recycler_view_list.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
               recycler_view_list.adapter = channelAdapter
//               presenter?.getChannelListSample(ToolbarListType.All)
               presenter?.getAllHomeList()
           }
       }

    }


}