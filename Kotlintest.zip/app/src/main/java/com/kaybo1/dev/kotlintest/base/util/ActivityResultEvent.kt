package com.kaybo1.dev.kotlintest.base.util

import android.content.Intent

/**
 * Created by Administrator on 2017-12-13.
 */
data class ActivityResultEvent(
        val requestCode : Int,
        val resultCode : Int,
        val data: Intent) {




}