package com.kaybo1.dev.kotlintest.community.adapter.presenter

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.support.v4.content.ContextCompat.startActivity
import android.util.Log
import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.base.util.createChannelInfoIntent
import com.kaybo1.dev.kotlintest.community.adapter.adapter.model.CommunityListAdapterContract
import com.kaybo1.dev.kotlintest.community.adapter.data.model.*
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.CommunityDataSource
import com.kaybo1.dev.kotlintest.fragmemts.SampleFragment
import com.kaybo1.dev.kotlintest.home.view.data.DummyListFactory
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import retrofit2.Call
import retrofit2.Response
import retrofit2.Callback


/**
 * Created by Administrator on 2017-12-28.
 */
class CommunityPresenter : CommunityContract.Presenter {

    private val handler = Handler(Looper.getMainLooper())
    private var isShowBlur = false
    override fun destroy() {
        handler.removeCallbacksAndMessages(null)
        isShowBlur = false
    }

    override fun getCommunityLists() {
        kayboData?.getCommunityList()?.enqueue(object : Callback<CommunityResponse>{
            override fun onResponse(call: Call<CommunityResponse>?, response: Response<CommunityResponse>?) {
                if(response?.isSuccessful ?: false){
                    val CommunityResponse = response?.body()
                    if(response?.raw()?.code()!!.equals(200)) {
                        communityResponseLists.add(CommunityResponse!!)

                        communityResponseLists.forEach {
                            adapterModel?.addCommunityItem(it)
                        }

                        AllLists = dummy
                        adapterAllListModel?.clear()
                        AllLists.forEach {
                            adapterAllListModel?.addAllChannelListItem(it)
                        }

                        HotChannelLists = CommunityResponse.hotChannel
                        HotChannelLists.forEach {
                            adapterHotChannelModel?.addHotChanneItem(it)
                        }
                        NewChannelLists = CommunityResponse.newChannel
                        NewChannelLists.forEach {
                            adapterNewChannelModel?.addNewChannelItem(it)
                        }
                        TopChannelLists = CommunityResponse.topChannel
                        TopChannelLists.forEach {
                            adapterTopChannelModel?.addTopChannelItem(it)
                        }
                        AllChannelByHotFlagIsFalseAndNewFlagIsFalseLists = CommunityResponse.allChannelByHotFlagIsFalseAndNewFlagIsFalse
                        AllChannelByHotFlagIsFalseAndNewFlagIsFalseLists.forEach {
                            adapterAllChannelModel?.addAllChannelDescItem(it)
                        }
                        MyChannelLists = CommunityResponse.myChannel
                        MyChannelLists.forEach {
                            adapterMyChannelModel?.addMyChannelItem(it)
                        }
                        val aa = HotChannelLists.size
                        val bb = NewChannelLists.size
                        val cc = TopChannelLists.size
                        val dd = MyChannelLists.size
                        val ee = AllChannelByHotFlagIsFalseAndNewFlagIsFalseLists.size
                        var Size = aa + bb + cc + dd + ee
                        adapterModel?.size(Size)


                        adapterView?.reload()
                        adapterHotChannelView?.reload()
                        adapterNewChannelView?.reload()
                        adapterTopChannelView?.reload()
                        adapterAllChannelView?.reload()
                        adapterMyChannelView?.reload()
                        adapterAllListView?.reload()
                        view?.showLoadSuccess()
                    }else{
                        view?.showLoadFailMessage("Code ${response?.raw()?.code()}, message ${response?.raw()?.message()}")
                    }
                }else{
                    view?.showLoadFail()
                }
            }

            override fun onFailure(call: Call<CommunityResponse>?, t: Throwable?) {
                view?.showLoadFail()
            }

        })


    }

    override var view: CommunityContract.View? = null

    override var kayboData: CommunityDataSource? = null
    override var adapterModel: CommunityListAdapterContract.Model? = null
    override var adapterView: CommunityListAdapterContract.View? = null
    override var adapterHotChannelModel: CommunityListAdapterContract.HotChannelModel? = null
    override var adapterHotChannelView: CommunityListAdapterContract.HotChannelView? = null
    override var adapterNewChannelModel: CommunityListAdapterContract.NewChannelModel? = null
    override var adapterNewChannelView: CommunityListAdapterContract.NewChannelView? = null
    override var adapterTopChannelModel: CommunityListAdapterContract.TopChannelModel? = null
    override var adapterTopChannelView: CommunityListAdapterContract.TopChannelView? = null
    override var adapterAllChannelModel: CommunityListAdapterContract.AllChannelDescModel? = null
    override var adapterAllChannelView: CommunityListAdapterContract.AllChannelDescView? = null
    override var adapterMyChannelModel: CommunityListAdapterContract.MyChannelModel? = null
    override var adapterMyChannelView: CommunityListAdapterContract.MyChannelView? = null
    override var adapterAllListModel: CommunityListAdapterContract.AllChannelListModel? = null
    override var adapterAllListView: CommunityListAdapterContract.AllChannelListView? = null
        set(value) {
            field = value

            field?.setOnItemTouchListener { motionEvent, i -> onItemTouchEvent(motionEvent,i) }
        }

    var communityResponseLists = ArrayList<CommunityResponse>()
    var HotChannelLists = ArrayList<HotChannel>()
    var NewChannelLists = ArrayList<NewChannel>()
    var TopChannelLists = ArrayList<TopChannel>()
    var AllChannelByHotFlagIsFalseAndNewFlagIsFalseLists = ArrayList<AllChannelByHotFlagIsFalseAndNewFlagIsFalse>()
    var MyChannelLists = ArrayList<MyChannel>()
    var AllLists = ArrayList<AllChannel>()
    var dummy : ArrayList<AllChannel> = DummyListFactory().AllChannelDummyLists

    var posX: Float = 0.0f
    var posY: Float = 0.0f
    private fun onItemTouchEvent(motionEvent: MotionEvent?, position: Int): Boolean {
        when (motionEvent?.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({
                    Log.i("TAG", "500!!!!")
                    val item = adapterAllListModel?.getItem(position)
                    item?.let {
                        //view?.showChannelDetail(item.channelId)
                        //startActivity(context.createChannelInfoIntent(2))
                    }
                }, 300L)
                motionEvent?.let {
                    onAdapterClick(position)

                }
                posX = motionEvent?.x ?: 0f
                posY = motionEvent?.y ?: 0f
            }
        }
        return true
    }
    private fun onAdapterClick(postion : Int) {
        adapterAllListModel?.getItems()?.let {
            view?.showChannelDetail(it[postion].channelId)
        }
    }

}