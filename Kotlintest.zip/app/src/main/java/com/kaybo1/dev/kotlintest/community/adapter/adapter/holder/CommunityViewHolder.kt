package com.kaybo1.dev.kotlintest.community.adapter.adapter.holder

import android.content.Context

import android.util.Log


import android.view.ViewGroup

import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R

import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder

import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_community.view.*


/**
 * Created by Administrator on 2017-12-29.
 */
class CommunityViewHolder(context: Context, parant: ViewGroup?,val onItemClickListener: OnItemClickListener?) :
        BaseViewHolder<AllChannel>(R.layout.list_community, context,parant){
    override fun bindView(item: AllChannel?, position: Int) {

        itemView?.let {
            with(it){
                tv_title.text = item?.title
                ImageDownload.loadImage(R.drawable.loading,image,item?.getImage())
                /*Glide.with(context)
                        .load(item?.getImage())
                        .centerCrop()
                        .placeholder(R.drawable.loading)
                        .into(image)*/
                it.setOnTouchListener { view, motionEvent ->
                    onItemClickListener?.onItemClick(motionEvent,position) ?: false
                }


            }
        }


    }


}