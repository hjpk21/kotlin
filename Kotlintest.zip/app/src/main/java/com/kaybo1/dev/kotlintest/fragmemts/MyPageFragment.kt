package com.kaybo1.dev.kotlintest.fragmemts

import android.os.Bundle
import android.view.View
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.util.createKcoinIntent
import tech.thdev.base.view.BaseFragment

/**
 * Created by Administrator on 2018-02-27.
 */
class MyPageFragment : BaseFragment() {
    override fun getLayout(): Int = R.layout.fragment_mypage

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        startActivity(context.createKcoinIntent("SampleToken"))
    }



}