package com.kaybo1.dev.kotlintest.home.view.data.model

import com.kaybo1.dev.kotlintest.BuildConfig
import com.kaybo1.dev.kotlintest.base.util.createRetrofit
import com.kaybo1.dev.kotlintest.network.CommunityServiceInterface
import com.kaybo1.dev.kotlintest.network.MainServiceInterface

/**
 * Created by Administrator on 2017-11-30.
 */
object KayboDataSource {

    val KAYBO_URL = BuildConfig.KAYBO_REAL_URL

    private val kayboServiceInterface : MainServiceInterface
    private val communityServiceInterface : CommunityServiceInterface

    init {
        kayboServiceInterface = createRetrofit(MainServiceInterface::class.java, KAYBO_URL)
        communityServiceInterface = createRetrofit(CommunityServiceInterface::class.java, KAYBO_URL)
    }

    fun getAllHomeList() = kayboServiceInterface.getAllSectionLists()
    fun getCommunityList() = communityServiceInterface.getCommunityLists()
}