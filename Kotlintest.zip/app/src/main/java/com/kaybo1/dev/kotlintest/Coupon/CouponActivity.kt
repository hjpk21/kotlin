package com.kaybo1.dev.kotlintest.Coupon

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.kaybo1.dev.kotlintest.Coupon.adapter.CouponFragmentPagerAdapter
import com.kaybo1.dev.kotlintest.R

/**
 * Created by Administrator on 2018-02-28.
 */
class CouponActivity : AppCompatActivity(){
    private var mViewPager: ViewPager? = null
    private var mSectionsPagerAdapter : CouponFragmentPagerAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coupon)
        mSectionsPagerAdapter = CouponFragmentPagerAdapter(this,supportFragmentManager)

        mViewPager = findViewById<ViewPager?>(R.id.container)
        mViewPager!!.adapter = mSectionsPagerAdapter

        val tabLayout = findViewById<View>(R.id.tabs) as TabLayout
        tabLayout.setupWithViewPager(mViewPager)

        tabLayout.getTabAt(0)!!.setIcon(R.drawable.bg_gnb_my)
        tabLayout.getTabAt(1)!!.setIcon(R.drawable.bg_gnb_my)
        tabLayout.getTabAt(2)!!.setIcon(R.drawable.bg_gnb_my)


    }
}