package com.kaybo1.dev.kotlintest.home.view.adapter.coupon

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import com.kaybo1.dev.kotlintest.fragmemts.CouponFragment
import com.kaybo1.dev.kotlintest.models.CouponToolbarListType

/**
 * Created by Administrator on 2017-12-12.
 */
class CouponPageAdapter (private val context: Context, fm: FragmentManager?) : FragmentPagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        when(position){
            0 -> return CouponFragment.couponInstanse()
            1 -> return CouponFragment.couponInstanse()
            2 -> return CouponFragment.couponInstanse()

        }
        return CouponFragment.couponInstanse()
    }

    override fun getCount(): Int {
        return 3
    }

}