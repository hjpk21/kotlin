package com.kaybo1.dev.kotlintest.PostDetail.adapter.holder

import android.content.Context
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_postcontents.view.*

/**
 * Created by Administrator on 2018-03-02.
 */
class PostContentViewHolder(context : Context, parent: ViewGroup?) : BaseViewHolder<PostContents>(R.layout.list_postcontents,context,parent){
    override fun bindView(item: PostContents?, position: Int) {
        itemView?.let {
            with(it){
                //image , video ,text 구분
                if(item?.content!!.startsWith("http")) {
                    //video
                    //ImageDownload.loadImage(R.drawable.loading, postcontent_image, item.getContentImage())
                }else if(item?.content!!.startsWith("/")){
                    //Image
                    ImageDownload.loadImage(R.drawable.loading, postcontent_image, item.getContentImage())
                }else{
                    //text
                    postcontent_text.text = item.content
                }
            }
        }
    }

}