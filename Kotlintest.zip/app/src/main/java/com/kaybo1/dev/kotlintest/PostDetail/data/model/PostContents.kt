package com.kaybo1.dev.kotlintest.PostDetail.data

import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-02-19.
 */
data class PostContents(val postContentId : String,
                        val postId : String,
                        val order : String,
                        val type : String,
                        var content : String){
    fun getContentImage() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        if(content != null){
            if(content.startsWith("/")){
                //Image
                content = url + "$content"
            }else{
                //read
                content
            }
        }
        return content
    }
}