package com.kaybo1.dev.kotlintest.home.view.adapter.model

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.home.view.data.*
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2017-11-28.
 */
interface ViewAdapterContract {
    interface View {
        fun Viewreload()
    }
    interface Model {
        fun addInfoItem(item:Info)
        fun addHomeResponse(item:HomeResponse)
        fun addChannelItem(item:ChannelList)
        fun addNoticeItem(item:NoticeList)
        fun addShortCutItem(item:ShortCutList)
        fun addHomeCartoonItem(item:HomeCartoonList)
        fun addDummyItem(item:DummyList)
        fun Modelclear()
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)
    }
    interface ChannelModel {
        fun addChannelItem(item:ChannelList)
        fun clear()
    }
    interface ChannelView {
        fun reload()
    }

    interface BannerModel {
        fun addBannerItem(item:BannerList)
        fun clear()
    }
    interface BannerView {
        fun reload()
    }

    interface NoticeModel {
        fun addNoticeItem(item:NoticeList)
        fun clear()
    }
    interface NoticeView {
        fun reload()
    }

    interface ShortCutModel {
        fun addShortCutItem(item:ShortCutList)
        fun clear()
    }
    interface ShortCutView {
        fun reload()
    }

    interface HomeCartoonModel {
        fun addHomeCartoonItem(item:HomeCartoonList)
        fun getItem(position: Int) : HomeCartoonList
        fun clear()
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)
    }
    interface HomeCartoonView {
        fun showLinkUrl(linkUrl : String)
        fun reload()
    }
    interface LoginModel {
        fun addLoginItem(item:Login)
        fun getLoginItem(position: Int) : Login?
    }

}