package com.kaybo1.dev.kotlintest.community.adapter.adapter.model

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.community.adapter.data.model.*
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2017-12-28.
 */
interface CommunityListAdapterContract{
    interface View {
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)
        fun reload()
    }
    interface Model {
        fun addCommunityItem(item:CommunityResponse)
        fun addCommunityAllItem(item:AllChannel)
        fun size(postion : Int) : AllChannel
        fun getItems() : ArrayList<AllChannel>
    }

    interface TopChannelModel {
        fun addTopChannelItem(item:TopChannel)
    }

    interface TopChannelView {
        fun reload()
    }

    interface NewChannelModel{
        fun addNewChannelItem(item:NewChannel)
    }

    interface NewChannelView {
        fun reload()
    }

    interface HotChannelModel {
        fun addHotChanneItem(item:HotChannel)
    }

    interface HotChannelView {
        fun reload()
    }

    interface AllChannelDescModel {
        fun addAllChannelDescItem(item:AllChannelByHotFlagIsFalseAndNewFlagIsFalse)
    }

    interface AllChannelDescView {
        fun reload()
    }

    interface MyChannelModel {
        fun addMyChannelItem(item:MyChannel)
    }
    interface MyChannelView {
        fun reload()
    }

    interface AllChannelListModel {
        fun addAllChannelListItem(item:AllChannel)
        fun getItems() : ArrayList<AllChannel>
        fun getItem(postion: Int) : AllChannel
        fun clear()
    }
    interface AllChannelListView {
        fun reload()
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)

    }


}