package com.kaybo1.dev.kotlintest.home.view.presenter

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import com.google.gson.JsonObject
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.*
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboLoginSource
import com.kaybo1.dev.kotlintest.models.ToolbarListType
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

/**
 * Created by Administrator on 2017-11-28.
 */
@SuppressLint("LongLogTag")
class SamplePresenter : SampleContract.Presenter {
    private val handler = Handler(Looper.getMainLooper())
    override var adapterModel: ViewAdapterContract.Model? = null
    override var adapterView: ViewAdapterContract.View? = null
    override var adapterNoticeModel: ViewAdapterContract.NoticeModel? = null
    override var adapterNoticeView: ViewAdapterContract.NoticeView? = null
    override var adapterShortCutModel: ViewAdapterContract.ShortCutModel? = null
    override var adapterShortCutView: ViewAdapterContract.ShortCutView? = null
    override var adapterHomeCartoonModel: ViewAdapterContract.HomeCartoonModel? = null
        set(value) {
            Log.d("TAG : [SamplePresenter] ","adapterHomeCartoonModel = "+value)

            field = value

            field?.setOnItemTouchListener { motionEvent, i -> onItemTouchEvent(motionEvent,i) }
        }
    override var adapterHomeCartoonView: ViewAdapterContract.HomeCartoonView? = null
    override var adapterBannerView: ViewAdapterContract.BannerView? = null
    override var adapterChannelView: ViewAdapterContract.ChannelView? = null
    override var adapterBannerModel: ViewAdapterContract.BannerModel? = null
    override var adapterChannelModel: ViewAdapterContract.ChannelModel? = null


    override fun getAllHomeList() {
        kayboData?.getAllHomeList()?.enqueue(object : Callback<HomeResponse> {
            override fun onFailure(call: Call<HomeResponse>?, t: Throwable?) {
                Log.d("TAG : [SamplePresenter]","onFailure",t)
                view?.showLoadFail()
            }

            override fun onResponse(call: Call<HomeResponse>?, response: Response<HomeResponse>?) {
                if(response?.isSuccessful ?: false) {
                    //Log.d("TAG","response raw " + response?.raw())

                    val homeResponse = response?.body()

                    hr.add(homeResponse!!)

                    hr.forEach {
                        adapterModel?.addHomeResponse(it)
                    }

                    adapterModel?.addInfoItem(homeResponse.info)

                    channelLists = homeResponse?.channelList

                    channelLists.forEach {
                        adapterChannelModel?.addChannelItem(it)
                        adapterModel?.addChannelItem(it)
                    }
                    bannerLists = homeResponse?.bannerList
                    bannerLists.forEach {
                        adapterBannerModel?.addBannerItem(it)

                    }
                    shortCutLists = homeResponse?.shortCutList
                    shortCutLists.forEach {
                        adapterShortCutModel?.addShortCutItem(it)
                        adapterModel?.addShortCutItem(it)
                    }
                    noticeLists = homeResponse?.noticeList
                    noticeLists.forEach {
                        adapterNoticeModel?.addNoticeItem(it)
                        adapterModel?.addNoticeItem(it)
                    }
                    homeCartoonLists = homeResponse?.homeCartoonList
                    homeCartoonLists.forEach {
                        adapterHomeCartoonModel?.addHomeCartoonItem(it)
                        adapterModel?.addHomeCartoonItem(it)
                    }
                    dummyLists = dummyListFactory.dummyLists
                    dummyLists.forEach {
                        adapterModel?.addDummyItem(it)
                    }

                    adapterView?.Viewreload()
                    adapterBannerView?.reload()
                    adapterChannelView?.reload()
                    adapterHomeCartoonView?.reload()
                    adapterNoticeView?.reload()
                    adapterShortCutView?.reload()
                }else{
                    Log.d("TAG : [SamplePresenter]"," else")
                    view?.showLoadFail()
                }
            }

        })
    }

    var dummyListFactory: DummyListFactory = DummyListFactory()
    var mListType: ToolbarListType = ToolbarListType.All
    var channelLists = ArrayList<ChannelList>()
    var bannerLists = ArrayList<BannerList>()
    var hr =  ArrayList<HomeResponse>()
    var info = ArrayList<Info>()
    var shortCutLists = ArrayList<ShortCutList>()
    var noticeLists = ArrayList<NoticeList>()
    var homeCartoonLists = ArrayList<HomeCartoonList>()
    var dummyLists = ArrayList<DummyList>()

    override fun getChannelListSample(listType: ToolbarListType) {
        if(mListType != listType) {
            adapterChannelModel?.clear()
        }
        mListType = listType
        channelLists = dummyListFactory.channelLists
        bannerLists = dummyListFactory.bannerLists


        channelLists.forEach {

            adapterChannelModel?.addChannelItem(it)
        }
        bannerLists.forEach{

            adapterBannerModel?.addBannerItem(it)
        }

        adapterView?.Viewreload()
    }

    override var view: SampleContract.View? = null

    override var kayboData: KayboDataSource? = null

    var posX: Float = 0.0f
    var posY: Float = 0.0f

    private fun onItemTouchEvent(motionEvent: MotionEvent?, position: Int): Boolean {
        when (motionEvent?.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({
                    Log.d("TAG", "500!!!!")

                }, 300L)
                motionEvent?.let {
                    Log.d("3333333333333333",position.toString())
                    onAdapterClick(position)
                }
                posX = motionEvent?.x ?: 0f
                posY = motionEvent?.y ?: 0f
            }
        }
        return true
    }
    private fun onAdapterClick(postion : Int) {
        adapterModel?.let {
            Log.d("TAG : [SamplePresenter]","onAdapterClick" + postion)
        }

        adapterHomeCartoonModel?.let {
            Log.d("TAG : [SamplePresenter] ","onAdapterClick")
            adapterHomeCartoonView?.showLinkUrl(it.getItem(postion).linkUrl)
            Log.d("TAG : [SamplePresenter] ","onAdapterClick2")
            view?.showLink(it.getItem(postion).linkUrl)
        }
        /*adapterAllListModel?.getItems()?.let {
            view?.showChannelDetail(it[postion].channelId)
        }*/
    }


}