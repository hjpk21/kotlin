package com.kaybo1.dev.kotlintest.home.view.data

/**
 * Created by Administrator on 2017-12-06.
 */
data class NoticeList (val noticeId : String,
                       val title: String,
                       val content : String,
                       val noticeDate : Any)