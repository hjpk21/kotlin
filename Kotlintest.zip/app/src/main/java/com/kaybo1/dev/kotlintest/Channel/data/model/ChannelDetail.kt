package com.kaybo1.dev.kotlintest.Channel.data.model

/**
 * Created by Administrator on 2018-01-23.
 */
data class ChannelDetail (val channelId : String,
                          val favoriteCount : String,
                          val totalPostCount : String,
                          val totalCommentCount : String,
                          val recentActiveDate : String,
                          val modifyDate : String)