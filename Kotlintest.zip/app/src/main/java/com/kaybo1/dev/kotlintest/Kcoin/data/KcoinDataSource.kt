package com.kaybo1.dev.kotlintest.Kcoin.data

import com.kaybo1.dev.kotlintest.BuildConfig
import com.kaybo1.dev.kotlintest.base.util.createRetrofit
import com.kaybo1.dev.kotlintest.network.KcoinServiceInterface

/**
 * Created by Administrator on 2018-02-26.
 */
object KcoinDataSource {
    val KAYBO_URL = BuildConfig.KAYBO_REAL_URL

    private val kcoinServiceInterface : KcoinServiceInterface

    init {
        kcoinServiceInterface = createRetrofit(KcoinServiceInterface::class.java, KAYBO_URL)
    }

    fun getKcoinBalance() = kcoinServiceInterface.getKcoinBalance()
}