package com.kaybo1.dev.kotlintest.community.adapter.data.model

import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel

/**
 * Created by Administrator on 2017-12-28.
 */
data class CommunityResponse(val topChannel: ArrayList<TopChannel>,
                             val allChannelByHotFlagIsFalseAndNewFlagIsFalse: ArrayList<AllChannelByHotFlagIsFalseAndNewFlagIsFalse>,
                             val hotChannel: ArrayList<HotChannel>,
                             val newChannel: ArrayList<NewChannel>,
                             val myChannel: ArrayList<MyChannel>,
                             val allChannel : ArrayList<AllChannel>) {

}