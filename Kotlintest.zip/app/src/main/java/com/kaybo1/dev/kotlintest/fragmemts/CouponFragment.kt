package com.kaybo1.dev.kotlintest.fragmemts

import android.annotation.SuppressLint
import com.kaybo1.dev.kotlintest.R
import tech.thdev.base.view.BaseFragment

@SuppressLint("ValidFragment")
/**
 * Created by Administrator on 2017-12-12.
 */
class CouponFragment() : BaseFragment(){
    override fun getLayout(): Int = R.layout.fragment_coupon

    companion object {
        fun couponInstanse() : CouponFragment {
            val fragment = CouponFragment()
            return fragment
        }
    }

}