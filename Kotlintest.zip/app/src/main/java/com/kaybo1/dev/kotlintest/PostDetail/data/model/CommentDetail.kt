package com.kaybo1.dev.kotlintest.PostDetail.data.model

/**
 * Created by Administrator on 2018-02-28.
 */
data class CommentDetail (val commentId : String,
                          val likeCount :String,
                          val modifyDate : String,
                          val likeComment : Boolean,
                          val myComment : Boolean)