package com.kaybo1.dev.kotlintest.Channel

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.activity_channelinfo.*
import kotlinx.android.synthetic.main.bottom_sheet_detail_view.*
import kotlinx.android.synthetic.main.fragment_channel_id.*
import tech.thdev.base.view.BaseFragment

/**
 * Created by Administrator on 2018-01-25.
 */
class ChannelIdFragment(val imageUrl: String) : BaseFragment(){
    override fun getLayout(): Int = R.layout.fragment_channel_id

    @SuppressLint("LongLogTag")
    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        img_large_view?.let {
            ImageDownload.loadImage(R.drawable.loading,img_large_view,imageUrl)
            /*Glide.with(this)
                    .load(imageUrl)
                    .centerCrop()
                    .crossFade()
                    .into(img_large_view)*/
        }
    }

}