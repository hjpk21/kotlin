package com.kaybo1.dev.kotlintest.home.view.adapter.holder

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.data.ChannelList
import com.kaybo1.dev.kotlintest.home.view.data.ShortCutList
import kotlinx.android.synthetic.main.list_single.view.*

/**
 * Created by Administrator on 2017-12-28.
 */
class ChannelViewHolder(resoruce: Int, context: Context, parent: ViewGroup) :
        RecyclerView.ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_channelsingle,parent,false)) {

    fun bindView(item: ChannelList?, position:Int){
        itemView?.let {
            with(it){

                Glide.with(context)
                        .load(item?.getImageUrl())
                        .centerCrop()
                        .placeholder(R.drawable.sample_00)
                        .into(image)
            }
        }

    }


}