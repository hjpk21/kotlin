package com.kaybo1.dev.kotlintest.PostDetail.data

import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-02-19.
 */
data class Member (val memberId: String,
                   val nickName: String,
                   val profileImage : String,
                   val joinDate : String,
                   val memberDetail : MemberDetail){
    fun getProfileImagUrl() : String {
        val url = BuildConfig.KAYBO_REAL_URL
        val thumbImage : String = url + "$profileImage"

        return thumbImage
    }
}