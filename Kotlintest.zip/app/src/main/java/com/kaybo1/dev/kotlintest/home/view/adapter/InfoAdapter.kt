package com.kaybo1.dev.kotlintest.home.view.adapter

import android.content.Context
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.holder.SampleViewHolder

import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.*
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.home.view.presenter.SamplePresenter
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2017-11-28.
 */
class InfoAdapter (private val context: Context) : RecyclerView.Adapter<InfoAdapter.AA>(), ViewAdapterContract.View,ViewAdapterContract.Model, SampleContract.View {
    override val onItemTouchListener: OnItemClickListener?
        get() = TODO("not implemented") //To change initializer of created properties use File | Settings | File Templates.

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showLink(linkUrl: String) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


    override fun addDummyItem(item: DummyList) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


    override fun addChannelItem(item: ChannelList) {
        itemChannel.add(item)
    }

    override fun addNoticeItem(item: NoticeList) {
        Log.d("InfoAdapter","addNoticeItem")
        itemNoticeList.add(item)
    }

    override fun addShortCutItem(item: ShortCutList) {
        Log.d("InfoAdapter","addShortCutItem")
        itemShortCut.add(item)
    }

    override fun addHomeCartoonItem(item: HomeCartoonList) {
        Log.d("InfoAdapter","addHomeCartoonItem")
        itemHomeCartoon.add(item)
    }

    override fun Viewreload() {
        Log.d("InfoAdapter","Viewreload")
        notifyDataSetChanged()
    }

    override fun Modelclear() {
        Log.d("InfoAdapter","Modelclear")
        info?.clear()
    }

    override fun addInfoItem(item: Info) {
        Log.d("InfoAdapter","addInfoItem")
        info.add(item)
    }

    override fun addHomeResponse(item: HomeResponse) {
        Log.d("InfoAdapter","addHomeResponse")
        itemhr.add(item)
    }

/*    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): SampleViewHolder {
        Log.d("InfoAdapter","onCreateViewHolder")
        return SampleViewHolder(viewType,context,parent!!)
    }

    override fun onBindViewHolder(holder: SampleViewHolder?, position: Int) {
            Log.d("InfoAdapter"," : onBindViewHolder")
            holder?.bindView(getInfoItem(position), position)

    }*/

    //    private var presenter : SampleContract.Presenter? = null
    private var channelAdapter : ChannelAdapter? = null
    private var bannerAdapter : BannerAdapter? = null

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): AA {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.list_item,null)
        val mh = AA(v)
        return mh
    }

   override fun onBindViewHolder(holder: AA?, position: Int) {

       when(position){
           0 -> presenters(holder)
           1 -> presenters2(holder)
       }

    }
    private fun presenters(holder: AA?) {

        var presenter : SampleContract.Presenter?
        presenter = SamplePresenter()
        holder?.itemTitle?.text = itemhr.get(0).info.communityTitle
        channelAdapter = ChannelAdapter(context)
        presenter?.kayboData = KayboDataSource
        presenter?.adapterChannelModel = channelAdapter
        presenter?.adapterChannelView = channelAdapter
        holder?.recycler_view_list?.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
        holder?.recycler_view_list?.adapter = channelAdapter
        presenter?.getAllHomeList()

    }
    private fun presenters2(holder: AA?) : Boolean{
        Log.d("2"," : 22222222222222")
        var presenter : SampleContract.Presenter?
        presenter = SamplePresenter()
        holder?.itemTitle?.text = itemhr.get(0).info.comicTitle
        bannerAdapter = BannerAdapter(context)
        presenter?.kayboData = KayboDataSource
        presenter?.adapterBannerModel = bannerAdapter
        presenter?.adapterBannerView = bannerAdapter
        holder?.recycler_view_list?.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL,false)
        holder?.recycler_view_list?.adapter = bannerAdapter
        presenter?.getAllHomeList()
        return false
    }

    override fun showLoadSuccess() {
        Toast.makeText(context, "Load success", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFail() {
        Toast.makeText(context, "Load fail", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFailMessage(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        Log.e("TAG", "Exception : " + message)
    }


    val itemhr : MutableList<HomeResponse> = ArrayList()
    val info : MutableList<Info> = ArrayList()
    val itemHomeCartoon : MutableList<HomeCartoonList> = ArrayList()
    val itemChannel : MutableList<ChannelList> = ArrayList()
    val itemNoticeList : MutableList<NoticeList> = ArrayList()
    val itemShortCut : MutableList<ShortCutList> = ArrayList()


    /*override fun onBindViewHolder(holder: SampleViewHolder?, position: Int) {
            holder?.bindView(gethrItem(position),position)
    }*/


/*    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): SampleViewHolder {
        return SampleViewHolder(viewType, context, parent!!)
    }*/

    override fun getItemCount() : Int {
        return (if (null != info) info.size else 0)
    }


    private fun getInfoItem(position: Int) = itemhr?.get(position)

    inner class AA(view:View) : RecyclerView.ViewHolder(view){
        val itemTitle: TextView
        val recycler_view_list : RecyclerView

        init {
            itemTitle = view.findViewById(R.id.itemTitle)
            recycler_view_list = view.findViewById(R.id.recycler_view_list)
        }
    }
}

