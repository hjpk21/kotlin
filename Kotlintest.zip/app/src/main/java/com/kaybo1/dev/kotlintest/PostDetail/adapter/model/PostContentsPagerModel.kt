package com.kaybo1.dev.kotlintest.PostDetail.adapter.model

import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents

/**
 * Created by Administrator on 2018-02-28.
 */
interface PostContentsPagerModel {
    var postContents : List<PostContents>?
}