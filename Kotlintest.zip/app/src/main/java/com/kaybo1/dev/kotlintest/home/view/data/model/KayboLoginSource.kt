package com.kaybo1.dev.kotlintest.home.view.data.model

import com.kaybo1.dev.kotlintest.BuildConfig
import com.kaybo1.dev.kotlintest.base.util.createRetrofit
import com.kaybo1.dev.kotlintest.home.view.data.Login
import com.kaybo1.dev.kotlintest.network.CommunityServiceInterface
import com.kaybo1.dev.kotlintest.network.LoginSeviceInterface
import com.kaybo1.dev.kotlintest.network.MainServiceInterface
import retrofit2.http.Header

/**
 * Created by Administrator on 2017-12-18.
 */
object KayboLoginSource {

    val KAYBO_URL = BuildConfig.KAYBO_REAL_URL

    private val loginSeviceInterface : LoginSeviceInterface


    init {
        loginSeviceInterface = createRetrofit(LoginSeviceInterface::class.java, KAYBO_URL)

    }

    fun getLoginAuthenticate(id:String,pw:String,nextUrl: String) = loginSeviceInterface.authenticate(id,pw,nextUrl)


}