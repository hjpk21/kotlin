package com.kaybo1.dev.kotlintest.Channel.presenter

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Channel.adapter.model.ChannelInfoListModel
import com.kaybo1.dev.kotlintest.Channel.adapter.model.PostListModel
import com.kaybo1.dev.kotlintest.Channel.data.ChannelInfoDataSource
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import tech.thdev.base.presenter.AbstractPresenter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
/**
 * Created by Administrator on 2018-01-18.
 */
@SuppressLint("LongLogTag")
class ChannelIdPresenter : AbstractPresenter<ChannelIdContract.View>(),ChannelIdContract.Presenter {


    private val handler = Handler(Looper.getMainLooper())
    private var isShowBlur = false

    override fun destroy() {
        handler.removeCallbacksAndMessages(null)
        isShowBlur = false
    }
    override var postListModel: PostListModel? = null
        set(value) {
                //Log.d("TAG :[ChannelIdPresenter] ","PostListModel = "+value)
                field = value

                field?.setOnItemTouchListener { motionEvent, i -> onItemTouchEvent(motionEvent,i) }
        }
    override var channelInfoListModel: ChannelInfoListModel? = null


    override fun setPostList(item: List<PostList>) {
        postListModel?.postList = item

    }
    override fun loadChannelPostLists(boardId: Int, categoryId: Int, pageable: Int, size: Int) {
        channelInfoDataSource?.getPostLIstResponse(boardId,categoryId,0,0)?.enqueue(object : Callback<List<PostList>>{
            override fun onResponse(call: Call<List<PostList>>?, response: Response<List<PostList>>?) {
                //Log.d("TAG : [ChannelIdPresenter] ","loadChannelPostLists Response: "+response?.raw().toString())
                if(response?.isSuccessful ?:false){
                    response?.body()?.let {
                        postListModel?.postList = it
                        view?.setPostList(it)
                    }
                }
            }

            override fun onFailure(call: Call<List<PostList>>?, t: Throwable?) {
                Log.d("TAG : [ChannelIdPresenter] ","loadChannelPostLists FAIL = " + t.toString())
            }

        })
    }

    override fun loadChannelPostList(channelId: Int) {
        channelInfoDataSource?.getChannelResponse(channelId)?.enqueue(object : Callback<List<ChannelResponse>> {
            override fun onFailure(call: Call<List<ChannelResponse>>?, t: Throwable?) {
                Log.d("TAG : [ChannelIdPresenter] ","loadChannelPostList FAIL = " + t.toString())
            }

            override fun onResponse(call: Call<List<ChannelResponse>>?, response: Response<List<ChannelResponse>>?) {
                //Log.d("TAG : [ChannelIdPresenter] ","loadChannelPostList Response : "+response?.raw().toString())
                if(response?.isSuccessful ?: false){
                    response?.body()?.let {
                        view?.setChannelInfo(it[0],it)
                    }
                }
            }

        })
    }

    override var channelInfoDataSource: ChannelInfoDataSource? = null

    private var backItem : ChannelInfo? = null

    private var ResponseItem : ChannelResponse? = null


    override fun loadChannelInfo(channelId: Int) {
        channelInfoDataSource?.getChannelInfo(channelId)?.enqueue(object : Callback<ChannelInfo> {
            override fun onFailure(call: Call<ChannelInfo>?, t: Throwable?) {
                Log.d("TAG : [ChannelIdPresenter] ","loadChannelInfo FAIL = " + t.toString())
            }

            override fun onResponse(call: Call<ChannelInfo>?, response: Response<ChannelInfo>?) {
                if(response?.isSuccessful ?: false){
                    response?.body()?.let {
                        //Log.d("TAG : [ChannelIdPresenter] ","loadChannelInfo Response:"+it)
                        backItem = it
                        view?.setItem(it)
                    }
                }
            }


        })

    }

    var posX: Float = 0.0f
    var posY: Float = 0.0f
    private fun onItemTouchEvent(motionEvent: MotionEvent?, position: Int): Boolean {
        when (motionEvent?.action) {
            MotionEvent.ACTION_DOWN -> {
                handler.removeCallbacksAndMessages(null)
                handler.postDelayed({
                    Log.i("TAG", "500!!!!")
                    val item = postListModel?.postList
                    item?.let {
                        //view?.showChannelDetail(item.channelId)
                        //startActivity(context.createChannelInfoIntent(2))
                    }
                }, 300L)
                motionEvent?.let {
                    onAdapterClick(position)

                }
                posX = motionEvent?.x ?: 0f
                posY = motionEvent?.y ?: 0f
            }
        }
        return true
    }
    private fun onAdapterClick(postion : Int) {
        postListModel?.postList?.let {
            view?.setChannelNum(it.get(postion).postId.toInt())
            //view?.setPostList(it)
        }
    }

}