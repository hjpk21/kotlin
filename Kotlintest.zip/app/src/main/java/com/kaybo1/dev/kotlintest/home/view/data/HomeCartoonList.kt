package com.kaybo1.dev.kotlintest.home.view.data

import android.util.Log
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2017-12-06.
 */
data class HomeCartoonList (val homeCartoonId : String,
                            val title : String,
                            val content : String,
                            var imageUrl : String,
                            val linkUrl : String,
                            val createDate :Any){
    fun getHomeCartoonImage() : String {
        if(imageUrl != null ){
            if(imageUrl.startsWith("http")){
                imageUrl
            }else{
            imageUrl = BuildConfig.KAYBO_REAL_URL+"$imageUrl"
            }
        }
        //Log.d("HomeCartoon thumb",imageUrl)
        return imageUrl
    }
}