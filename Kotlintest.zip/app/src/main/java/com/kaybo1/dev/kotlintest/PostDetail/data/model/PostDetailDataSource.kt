package com.kaybo1.dev.kotlintest.PostDetail.data.model

import com.kaybo1.dev.kotlintest.BuildConfig
import com.kaybo1.dev.kotlintest.base.util.createRetrofit
import com.kaybo1.dev.kotlintest.network.PostDetailServiceInterface

/**
 * Created by Administrator on 2018-02-19.
 */
object PostDetailDataSource {
    val KAYBO_URL = BuildConfig.KAYBO_REAL_URL

    private val postDetailServiceInterface : PostDetailServiceInterface

    init {
        postDetailServiceInterface = createRetrofit(PostDetailServiceInterface::class.java, KAYBO_URL)
    }

    fun getPostDetailResponse(postId : Int) = postDetailServiceInterface.getPostDetailResponse(postId)
    fun getPostCommentResponse(postId: Int) = postDetailServiceInterface.getPostCommentResponse(postId)
}