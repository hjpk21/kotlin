package com.kaybo1.dev.kotlintest.fragmemts

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.app.Fragment
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.*
import android.widget.Toast
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.util.ActivityResultEvent
import com.kaybo1.dev.kotlintest.base.util.createChannelInfoIntent
import com.kaybo1.dev.kotlintest.community.adapter.adapter.CommunityListAdapter
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.CommunityDataSource
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityContract
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityPresenter
import com.kaybo1.dev.kotlintest.home.view.adapter.*
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.home.view.presenter.LoginContract
import com.kaybo1.dev.kotlintest.home.view.presenter.LoginPresenter
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.home.view.presenter.SamplePresenter
import com.kaybo1.dev.kotlintest.models.ToolbarListType
import kotlinx.android.synthetic.main.fragment_community.*
import kotlinx.android.synthetic.main.fragment_sample.*

/**
 * Created by Administrator on 2018-01-02.
 */

@SuppressLint("ValidFragment")
/**
 * Created by Administrator on 2017-11-27.
 */
class CommunityFragment(passedContext: Context) : Fragment(), LoginContract.View, CommunityContract.View {
    override fun showChannelDetail(channelId: String) {
        startActivity(context.createChannelInfoIntent(channelId))
    }

    override fun showToast(title: String) {
        Toast.makeText(passThroughContext,"$title", Toast.LENGTH_SHORT).show()
    }

    private val fab by lazy {
        activity.findViewById<FloatingActionButton>(R.id.fab) as FloatingActionButton
    }

    companion object {
        val ARG_LIST_TYPE = "LIST_TYPE"

        fun newInstance(listType: ToolbarListType, context: Context) : CommunityFragment {
            val fragment = CommunityFragment(context)
            val args = Bundle()
            args.putSerializable(ARG_LIST_TYPE,listType)
            fragment.arguments = args
            return fragment
        }
    }


    private var homeListAdapter : HomeListAdapter?  = null

    private var commnityListAdapter : CommunityListAdapter? = null

    private var presenter : SampleContract.Presenter? = null

    private var presenters : LoginContract.Presenter? = null

    private var communitypresenter : CommunityContract.Presenter? = null

    val passThroughContext : Context = passedContext

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?  {

        return inflater.inflate(R.layout.fragment_community, container,false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val listType = this.arguments.getSerializable(SampleFragment.ARG_LIST_TYPE) as ToolbarListType
        when(listType){
            ToolbarListType.All -> changeViewType(listType)
            ToolbarListType.Active -> changeViewType(listType)
            ToolbarListType.Small -> changeViewType(listType)
            ToolbarListType.LeashTrained -> changeViewType(listType)
            ToolbarListType.Big -> changeViewType(listType)
        }
        /*communitypresenter = CommunityPresenter()
        communitypresenter?.view = this
        commnityListAdapter = CommunityListAdapter(passThroughContext)
        communitypresenter?.kayboData = CommunityDataSource
        communitypresenter?.adapterAllListModel = commnityListAdapter
        communitypresenter?.adapterAllListView = commnityListAdapter
        //community_recycler_view.layoutManager = GridLayoutManager(passThroughContext,3)
        recycler_image.adapter = commnityListAdapter
        fab.setOnClickListener {
            Toast.makeText(context,"Community Click", Toast.LENGTH_SHORT).show()
            (activity as LoginContract).replaceFragment(1)
        }
        communitypresenter?.getCommunityLists()*/
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater?.inflate(R.menu.menu_main,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun showLoadSuccess() {
        Toast.makeText(context, "Load success", Toast.LENGTH_SHORT).show()
    }

    @SuppressLint("LongLogTag")
    override fun showLoadFail() {
        Log.d("TAG : [CommunityFragment]",""+context)
        Toast.makeText(context, "Load Fail", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFailMessage(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        Log.e("TAG", "Exception : " + message)
    }

    private fun changeViewType(listType: ToolbarListType)  = when(listType) {
        ToolbarListType.All -> community()
        ToolbarListType.Active -> community()
        ToolbarListType.Small -> community()
        ToolbarListType.LeashTrained -> community()
        ToolbarListType.Big -> community()
    }
    private fun homeList(){
        /*presenter = SamplePresenter()
        presenters = LoginPresenter()
        presenter?.view = this
        presenters?.view = this
        homeListAdapter = HomeListAdapter(passThroughContext)
        presenter?.kayboData = KayboDataSource
        presenter?.adapterModel = homeListAdapter
        presenter?.adapterView = homeListAdapter
        my_recycler_view.layoutManager = LinearLayoutManager(passThroughContext, LinearLayoutManager.VERTICAL,false)
        my_recycler_view.adapter = homeListAdapter

        presenter?.getAllHomeList()*/
    }

    private fun coupon() {

        //Log.d("Get","Retrofit2")
        //loginPresenter?.getLoginResponse("fhl-2","rkdalsrl!","my")
        //Log.d("email","Retrofit2")
        //loginPresenter?.email("fhl-2")



        //loginPresenter?.getBody(this!!.login!!)

        //loginPresenter?.getLoginRequest("fhl-2","rkdalsrl!")
        Log.d("Get","Retrofit2")
    }
    private fun community(){
        communitypresenter = CommunityPresenter()
        communitypresenter?.view = this
        commnityListAdapter = CommunityListAdapter(passThroughContext)
        communitypresenter?.kayboData = CommunityDataSource
        communitypresenter?.adapterAllListModel = commnityListAdapter
        communitypresenter?.adapterAllListView = commnityListAdapter
        recycler_image.layoutManager = GridLayoutManager(passThroughContext,1)
        recycler_image.setHasFixedSize(true)
        recycler_image.adapter = commnityListAdapter

        communitypresenter?.getCommunityLists()
    }

    private fun myPage() {

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        ActivityResultEvent(requestCode,resultCode, data!!)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_async -> {
                changeViewType(ToolbarListType.All)
                return true
            }
            R.id.action_thread -> {
                changeViewType(ToolbarListType.Big)
                return true
            }
            R.id.action_glide -> {
                changeViewType(ToolbarListType.Small)
                return true
            }
            else -> {
                return super.onOptionsItemSelected(item)
            }
        }

    }





}