package com.kaybo1.dev.kotlintest.fragmemts

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask

import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentTransaction
import android.support.v7.widget.GridLayoutManager

import android.support.v7.widget.LinearLayoutManager

import android.util.Log
import android.view.*
import android.widget.GridView
import android.widget.Toast
import com.kaybo1.dev.kotlintest.LoginActivity

import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.fragment.BaseFragment
import com.kaybo1.dev.kotlintest.base.util.*
import com.kaybo1.dev.kotlintest.community.adapter.adapter.CommunityListAdapter
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.CommunityDataSource
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityContract
import com.kaybo1.dev.kotlintest.community.adapter.presenter.CommunityPresenter

import com.kaybo1.dev.kotlintest.home.view.adapter.*
import com.kaybo1.dev.kotlintest.home.view.data.Login

import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboLoginSource
import com.kaybo1.dev.kotlintest.home.view.presenter.LoginContract
import com.kaybo1.dev.kotlintest.home.view.presenter.LoginPresenter
import com.kaybo1.dev.kotlintest.home.view.presenter.SampleContract
import com.kaybo1.dev.kotlintest.home.view.presenter.SamplePresenter
import com.kaybo1.dev.kotlintest.models.ToolbarListType

import kotlinx.android.synthetic.main.fragment_sample.*
import kotlinx.android.synthetic.main.list_item.*
import retrofit2.http.Header


@SuppressLint("ValidFragment")
/**
 * Created by Administrator on 2017-11-27.
 */
class SampleFragment(passedContext: Context) : Fragment(), SampleContract.View,LoginContract.View {
    override fun showLink(linkUrl: String) {
        Log.d("TAG : [SampleFragment] ","showLink "+linkUrl)
    }
    /*override fun showHomeCartoonLInk(linkUrl: String) {
        Log.d("TAG : [SampleFragment] ","showHomeCatoonLink")
        var i = Intent(Intent.ACTION_VIEW, Uri.parse(linkUrl))
        context.startActivity(i)
    }*/

    override fun showToast(title: String) {
        Toast.makeText(passThroughContext,"SampleFragment ",Toast.LENGTH_SHORT).show()
    }

    private val fab by lazy {
        activity.findViewById<FloatingActionButton>(R.id.fab) as FloatingActionButton
    }

    companion object {
        val ARG_LIST_TYPE = "LIST_TYPE"

        fun newInstance(listType:ToolbarListType, context: Context) : SampleFragment {
            val fragment = SampleFragment(context)
            val args = Bundle()
            args.putSerializable(ARG_LIST_TYPE,listType)
            fragment.arguments = args
            return fragment
        }

        fun instance() : FirstFragment {
            val fragment  = FirstFragment()
            val args = Bundle()
            args.putSerializable("channel","60")
            fragment.arguments = args
            return fragment
        }
    }

    private var homeListAdapter : HomeListAdapter?  = null

    private var commnityListAdapter : CommunityListAdapter? = null

    private var presenter : SampleContract.Presenter? = null

    private var presenters : LoginContract.Presenter? = null

    private var communitypresenter : CommunityContract.Presenter? = null

    val passThroughContext : Context = passedContext

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }
    override fun onCreateView(inflater: LayoutInflater?, container: ViewGroup?, savedInstanceState: Bundle?): View?  {

        return inflater?.inflate(R.layout.fragment_sample, container,false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val listType = this.arguments.getSerializable(ARG_LIST_TYPE) as ToolbarListType
        when(listType){
            ToolbarListType.All -> changeViewType(listType)
            ToolbarListType.Active -> changeViewType(listType)
            ToolbarListType.Small -> changeViewType(listType)
            ToolbarListType.LeashTrained -> changeViewType(listType)
            ToolbarListType.Big -> changeViewType(listType)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater?.inflate(R.menu.menu_main,menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun showLoadSuccess() {
        Toast.makeText(passThroughContext, "Load Success", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFail() {
        Log.d("TAG : [SampleFragment] ","showLoadFail : "+context)
        Toast.makeText(passThroughContext, "Load Fail", Toast.LENGTH_SHORT).show()
    }

    override fun showLoadFailMessage(message: String) {
        Toast.makeText(passThroughContext, message, Toast.LENGTH_LONG).show()
        Log.e("TAG", "Exception : " + message)
    }

    private fun changeViewType(listType: ToolbarListType)  = when(listType) {
        ToolbarListType.All -> homeList()
        ToolbarListType.Active -> coupon()
        ToolbarListType.Small -> community()
        ToolbarListType.LeashTrained -> KcoinPage()
        ToolbarListType.Big -> myPage()
    }
    private fun homeList(){
        presenter = SamplePresenter()
        presenters = LoginPresenter()
        presenter?.view = this
        presenters?.view = this
        homeListAdapter = HomeListAdapter(passThroughContext)
        presenter?.kayboData = KayboDataSource
        presenter?.adapterModel = homeListAdapter
        presenter?.adapterView = homeListAdapter
        my_recycler_view.layoutManager = LinearLayoutManager(passThroughContext,LinearLayoutManager.VERTICAL,false)
        my_recycler_view.adapter = homeListAdapter
        fab.setOnClickListener {
            Toast.makeText(passThroughContext,"Community Click", Toast.LENGTH_SHORT).show()
            (activity as LoginContract).replaceFragment(1)
        }
        presenter?.getAllHomeList()
    }

    private fun coupon() {
        Toast.makeText(passThroughContext,"Coupon",Toast.LENGTH_SHORT).show()
    }
    private fun community(){
        Toast.makeText(passThroughContext,"Community",Toast.LENGTH_SHORT).show()
    }
    private fun KcoinPage(){
        Toast.makeText(passThroughContext,"KcoinPage",Toast.LENGTH_SHORT).show()
        //startActivity(context.createKcoinIntent("SampleToken"))
        //dummy 여기서 보이는 페이지 표기
        mAuthTask = ChangePageTask()
        mAuthTask!!.execute(null as Void?)
}
    private fun myPage() {
        Toast.makeText(passThroughContext,"myPage",Toast.LENGTH_SHORT).show()
        //startActivity(context.createKcoinIntent("SampleToken"))
        //dummy 여기서 보이는 페이지 표기
        mAuthTask = ChangePageTask()
        mAuthTask!!.execute(null as Void?)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        ActivityResultEvent(requestCode,resultCode, data!!)
    }

    private fun loginPage(){
        Toast.makeText(passThroughContext,"loginPage",Toast.LENGTH_SHORT).show()
        startActivity(passThroughContext.createLoginIntent())
        //startActivity(context.createChannelInfoIntent("2"))
        //(activity as LoginContract).replaceFragment(1)
    }
    private fun channelinfo(){
        //임시 channel test
        Toast.makeText(passThroughContext,"channelinfo",Toast.LENGTH_SHORT).show()
        startActivity(passThroughContext.createChannelInfoIntent("2"))
    }
    private fun postDetail(){
        //122488
        //startActivity(context.createPostDummyIntent("122488"))
        startActivity(passThroughContext.createPostDetailIntent("122488"))
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_async -> {
                loginPage()
                return true
            }
            R.id.action_thread -> {
                channelinfo()
                return true
            }
            R.id.action_glide -> {
                postDetail()
                return true
            }
            else -> {
                return super.onOptionsItemSelected(item)
            }
        }

    }
    private var mAuthTask : ChangePageTask? = null

    inner class ChangePageTask internal constructor() : AsyncTask<Void,Void,Boolean>(){
        override fun doInBackground(vararg params: Void?): Boolean {

            return true
        }

    }





}