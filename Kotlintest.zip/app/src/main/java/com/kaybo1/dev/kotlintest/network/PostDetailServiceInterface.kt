package com.kaybo1.dev.kotlintest.network


import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * Created by Administrator on 2018-02-19.
 */
interface PostDetailServiceInterface {
    @GET("api/community/postDetail/{postId}")
    fun getPostDetailResponse(@Path("postId") postId: Int): Call<PostDetailResponse>

    @GET("api/community/comments/post/{postId}")
    fun getPostCommentResponse(@Path("postId") postId: Int): Call<List<CommentsResponse>>
}