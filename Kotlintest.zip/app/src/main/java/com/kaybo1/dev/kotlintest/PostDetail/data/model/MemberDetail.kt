package com.kaybo1.dev.kotlintest.PostDetail.data

/**
 * Created by Administrator on 2018-02-19.
 */
data class MemberDetail (val memberId :String,
                         val totalPoint : String,
                         val currentPoint : String,
                         val totalCouponCount : String,
                         val currentCouponCount : String,
                         val totalPostCount : String,
                         val totalCommentCount : String,
                         val todayTranslateTotalPoint : String,
                         val modifyDate :String,
                         val recentLoginDate : String,
                         val memberScore : String)