package com.kaybo1.dev.kotlintest.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.AsyncTask
import android.support.annotation.DrawableRes
import android.text.TextUtils
import android.util.LruCache
import android.widget.ImageView
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.lang.ref.WeakReference
import java.net.URL
import java.net.URLConnection

/**
 * Created by Administrator on 2018-01-08.
 */
object ImageDownload {
    private val cache = LruCache<String, WeakReference<Bitmap>>(5 * 1024 * 1024)

    fun loadImage(@DrawableRes loadImage: Int, imageView: ImageView, url: String?) {
        url?.let {
            val weakReference = cache.get(url)
            if (weakReference == null || weakReference.get() == null) {
                imageView.tag = url

                imageView.setImageResource(loadImage)
                ImageAsync(imageView).execute(url)
            } else {
                imageView.setImageBitmap(weakReference.get())
            }
        }
    }

    private class ImageAsync(imageView: ImageView) : AsyncTask<String, String, String>() {

        private val weakReferenceImageView: WeakReference<ImageView>

        internal var connection: URLConnection? = null
        internal var inputStream: InputStream? = null
        internal var bufferedInputStream: BufferedInputStream? = null

        init {
            this.weakReferenceImageView = WeakReference(imageView)
        }

        override fun doInBackground(vararg params: String?): String? {
            try {
                val urlString = params[0]
                val url = URL(urlString)
                connection = url.openConnection()
                connection?.connect()

                inputStream = connection?.inputStream
                bufferedInputStream = BufferedInputStream(inputStream)

                cache.put(urlString, WeakReference(BitmapFactory.decodeStream(bufferedInputStream)))
                return urlString

            } catch (e: IOException) {
                closeStream()
            } finally {
                closeStream()
            }
            return null
        }
        private fun closeStream(){
            try {
                if(inputStream != null) {
                    inputStream!!.close()
                    inputStream = null
                }
                if(bufferedInputStream != null){
                    bufferedInputStream!!.close()
                    bufferedInputStream = null
                }
            }catch (e1 : IOException){
                e1.printStackTrace()
            }
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            if(isCancelled){
                return
            }
            val imageView = weakReferenceImageView.get()
            if(!TextUtils.isEmpty(result) &&
                    imageView != null &&
                    imageView.tag != null &&
                    imageView.tag == result &&
                    cache.get(result) != null &&
                    cache.get(result).get() != null){
                imageView.setImageBitmap(cache.get(result).get())
            }
        }

    }
}