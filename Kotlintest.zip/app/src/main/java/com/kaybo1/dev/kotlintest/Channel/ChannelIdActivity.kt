package com.kaybo1.dev.kotlintest.Channel

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.v4.view.ViewPager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.Channel.adapter.ChannelInfoListAdapter
import com.kaybo1.dev.kotlintest.Channel.adapter.PostListAdapter
import com.kaybo1.dev.kotlintest.Channel.data.ChannelInfoDataSource
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.Channel.presenter.ChannelIdContract
import com.kaybo1.dev.kotlintest.Channel.presenter.ChannelIdPresenter
import com.kaybo1.dev.kotlintest.PostDetail.PostDetailActivity
import com.kaybo1.dev.kotlintest.PostDetail.PostDetailFragment
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.util.createChannelInfoIntent
import com.kaybo1.dev.kotlintest.base.util.createPostDetailIntent
import com.kaybo1.dev.kotlintest.base.util.createPostDummyIntent
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import kotlinx.android.synthetic.main.activity_channelinfo.*
import kotlinx.android.synthetic.main.bottom_sheet_detail_view.*
import tech.thdev.base.view.BasePresenterActivity

/**
 * Created by Administrator on 2018-01-18.
 */
@SuppressLint("LongLogTag")
class ChannelIdActivity : BasePresenterActivity<ChannelIdContract.View, ChannelIdContract.Presenter>() , ChannelIdContract.View, ViewPager.OnPageChangeListener {

    override fun setChannelNum(postId: Int) {
        Log.d("TAG [ChannelIdActivity] ","setChannelNum = "+postId)
        //startActivity(this.createPostDetailIntent(postId.toString()))
        startActivity(this.createPostDummyIntent(postId.toString()))
    }

    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                //Log.d("TAG : [ChannelIdActivity]","onItemClick : "+postion)
                return onTouch(motionEvent,postion)
            }
        }
    }

    var isLoading = true
    override fun setPostList(item: List<PostList>) {
        //Log.d("TAG : [ChannelIdActivity] ","setPostList :"+item)
        postListAdapter = PostListAdapter(applicationContext, item)
        presenter?.postListModel = postListAdapter
        tv_content_list.adapter = postListAdapter
        tv_content_list.layoutManager = LinearLayoutManager(applicationContext,LinearLayoutManager.VERTICAL,false)
        item.forEach {
            //channel_name.text = it.title
            //ImageDownload.loadImage(R.drawable.loading, channel_image, it.getImageUrl())
        }
        isLoading = false
    }

    override fun onPageScrollStateChanged(state: Int) {

    }

    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {

    }

    override fun onPageSelected(position: Int) {
        //여기 포지션으로 좌우 넘길때 채널/페이지 이동 가능
        Log.d("TAG : [ChannelIdActivity] ", "onPageSelected : "+position.toString())
        when (position) {
            position -> Log.d("TAG : [ChannelIdActivity] ","postion : "+position.toString())
        }
    }

    private var channelInfoListAdapter: ChannelInfoListAdapter? = null

    private var postListAdapter : PostListAdapter? = null

    private var isShowInfoIcon = false


    override fun setChannelInfo(item: ChannelResponse,items:List<ChannelResponse>) {
        channelInfoListAdapter = ChannelInfoListAdapter(supportFragmentManager,items)
        presenter?.channelInfoListModel = channelInfoListAdapter

        container.adapter = channelInfoListAdapter
        container.addOnPageChangeListener(this)
        isLoading = true
        presenter?.loadChannelInfo(item.channel.channelId.toInt())

        var boardId = item.boardId.toInt()
        presenter?.loadChannelPostLists(boardId, 0, 0, 0)
        //이곳에서 넘기셔 다시 그리기
        isLoading = false

    }

    val bottomSheet by lazy {
        BottomSheetBehavior.from(rl_sheet_view)
    }

    override fun setItem(item: ChannelInfo) {
        rl_toolbar_user_info.visibility = View.VISIBLE
        rl_toolbar_image_info.visibility = View.GONE


        title = item.channelName
        tv_viewer_count.text = item.favoriteCount
        tv_comment_count.text = item.totalPostCount
        tv_toolbar_title.text = item.channelName

        Glide.with(this)
                .load(item.getthumbImageUrl())
                .centerCrop()
                .crossFade()
                .into(img_small)

        Glide.with(this)
                .load(item.getthumbImageUrl())
                .centerCrop()
                .crossFade()
                .into(fab)
        button2.setOnClickListener {
            var i = Intent(Intent.ACTION_VIEW, Uri.parse(item.playUrl))
            startActivity(i)
        }

    }

    override fun onCreatePresenter() = ChannelIdPresenter()

    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_channelinfo)

        setSupportActionBar(toolbar)
        title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        presenter?.channelInfoDataSource = ChannelInfoDataSource

        val channelId: Int = intent.getStringExtra("channelId").toInt()

        attemptLogin(channelId)

        onCreateView()

        //
        //presenter?.loadChannelPostList(channelId)


    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)

    }
    private fun onCreateView(){
        bottomSheet.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback(){
            override fun onSlide(bottomSheet: View, slideOffset: Float) {
                if(slideOffset > 0.9){
                    rl_toolbar_user_info.visibility = View.GONE
                    rl_toolbar_image_info.visibility = View.VISIBLE
                    tv_title.visibility = View.INVISIBLE
                    isShowInfoIcon = true
                }else{
                    rl_toolbar_user_info.visibility = View.VISIBLE
                    rl_toolbar_image_info.visibility = View.GONE
                    tv_title.visibility = View.VISIBLE
                    isShowInfoIcon = false
                }
            }

            override fun onStateChanged(bottomSheet: View, newState: Int) {
                if(newState == BottomSheetBehavior.STATE_HIDDEN) {
                    onBackPressed()
                }
            }

        })
        fab.setOnClickListener{
            //여기서?
        }
    }

    private var mAuthTask: ChannelIdActivity.GetBoardId? = null

    private fun attemptLogin(channelId:Int) {
        if (mAuthTask != null) {
            return
        }
        mAuthTask = GetBoardId(channelId)
        mAuthTask!!.execute(null as Void?)
    }

    inner class GetBoardId internal constructor(private val channelId: Int) : AsyncTask<Void, Void, Boolean>() {
        override fun doInBackground(vararg params: Void?): Boolean {
            try{

                presenter?.loadChannelPostList(channelId)

            } catch (e : InterruptedException){
                return false
            }
            return true
        }


    }
}