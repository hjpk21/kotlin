package com.kaybo1.dev.kotlintest.listener

import android.view.MotionEvent

/**
 * Created by Administrator on 2018-01-19.
 */
interface OnItemClickListener {
    fun onItemClick(motionEvent: MotionEvent?, postion : Int) : Boolean
}