package com.kaybo1.dev.kotlintest.community.adapter.presenter

import android.content.Intent
import android.text.InputFilter
import com.kaybo1.dev.kotlintest.community.adapter.adapter.model.CommunityListAdapterContract
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.CommunityDataSource
import com.kaybo1.dev.kotlintest.home.view.data.model.KayboDataSource

/**
 * Created by Administrator on 2017-12-28.
 */
interface CommunityContract {
    interface View {
        /**
         * 로딩 완료
         */
        fun showLoadSuccess()

        /**
         * 로딩 실패
         */
        fun showLoadFail()

        fun showLoadFailMessage(message: String)
        /*
        *  채널 ID만 넘겨서 처리 (Info,Board분리)
        * */
        fun showChannelDetail(channelId : String)

    }
    interface Presenter {
        var view : View?
        var kayboData : CommunityDataSource?
        var adapterModel : CommunityListAdapterContract.Model?
        var adapterView : CommunityListAdapterContract.View?
        var adapterHotChannelModel : CommunityListAdapterContract.HotChannelModel?
        var adapterHotChannelView : CommunityListAdapterContract.HotChannelView?
        var adapterNewChannelModel : CommunityListAdapterContract.NewChannelModel?
        var adapterNewChannelView : CommunityListAdapterContract.NewChannelView?
        var adapterTopChannelModel : CommunityListAdapterContract.TopChannelModel?
        var adapterTopChannelView : CommunityListAdapterContract.TopChannelView?
        var adapterAllChannelModel : CommunityListAdapterContract.AllChannelDescModel?
        var adapterAllChannelView : CommunityListAdapterContract.AllChannelDescView?
        var adapterMyChannelModel : CommunityListAdapterContract.MyChannelModel?
        var adapterMyChannelView : CommunityListAdapterContract.MyChannelView?
        var adapterAllListModel : CommunityListAdapterContract.AllChannelListModel?
        var adapterAllListView : CommunityListAdapterContract.AllChannelListView?

        fun getCommunityLists()

        fun destroy()


    }
}