package com.kaybo1.dev.kotlintest.adapters

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.Login


/**
 * Created by Administrator on 2017-12-13.
 */
class LoginAdapter (val context: Context) : ViewAdapterContract.LoginModel{
    val loginList : MutableList<Login>? = null

    override fun addLoginItem(item: Login) {
        Log.d("LoginAdapter : ",item.toString())
        loginList?.add(item)
    }

    override fun getLoginItem(position: Int): Login? {
        Log.d("LoginAdapter get : ",loginList?.get(position).toString())
        return loginList?.get(position)
    }


}