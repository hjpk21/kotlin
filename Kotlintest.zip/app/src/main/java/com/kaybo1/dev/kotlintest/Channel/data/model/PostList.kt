package com.kaybo1.dev.kotlintest.Channel.data.model

import android.util.Log
import com.kaybo1.dev.kotlintest.BuildConfig

/**
 * Created by Administrator on 2018-01-24.
 */
data class PostList(val postId : String,
                    val channelId : String,
                    val title : String,
                    val profileImageUrl : String,
                    val memberNickname: String,
                    val memberScore : String,
                    val writeDate : String,
                    val type : String,
                    var thumbImageUrl : String,
                    val commentCount : String,
                    val likeCount : String,
                    val shareCount : String,
                    val content : String){
    fun getImageUrl() : String{
        if(thumbImageUrl != null) {
            if (thumbImageUrl.startsWith("http")) {
                //Log.d("TAG : [PostList]","thumbImagUrl startWith : "+thumbImageUrl)
                thumbImageUrl
            } else {
                thumbImageUrl = BuildConfig.KAYBO_REAL_URL+"$thumbImageUrl"
                //Log.d("TAG : [PostList]","thumblmageUrl : "+thumbImageUrl)
            }
        }else{

        }

        return thumbImageUrl
    }
}