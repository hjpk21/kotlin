package com.kaybo1.dev.kotlintest.Channel.adapter

import android.annotation.SuppressLint
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.util.Log
import com.kaybo1.dev.kotlintest.Channel.ChannelIdActivity
import com.kaybo1.dev.kotlintest.Channel.ChannelIdFragment
import com.kaybo1.dev.kotlintest.Channel.adapter.model.ChannelInfoListModel
import com.kaybo1.dev.kotlintest.Channel.data.ChannelInfoDataSource.getChannelInfo
import com.kaybo1.dev.kotlintest.Channel.data.model.ChannelResponse
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList

/**
 * Created by Administrator on 2018-01-18.
 */
@SuppressLint("LongLogTag")
class ChannelInfoListAdapter(fragmentManager : FragmentManager,itmes:List<ChannelResponse>) : FragmentPagerAdapter(fragmentManager), ChannelInfoListModel{
    override fun getMainImageUrl(): String = channelInfoItemList?.getOrNull(0)?.channel?.getmainImageUrl() ?: ""

    override fun getThumbMainImageUrl(): String = channelInfoItemList?.getOrNull(0)?.channel?.getthumbImageUrl() ?: ""

    override var channelInfoItemList: List<ChannelResponse>? = itmes

    override fun getItem(position: Int): Fragment {
        Log.d("TAG : [ChannelInfoListAdapter] ","getItem : "+position.toString())
        return ChannelIdFragment(getMainImageUrl())
    }

    override fun getCount(): Int = channelInfoItemList?.size ?:0





}