package com.kaybo1.dev.kotlintest.Kcoin.presenter

import android.view.MotionEvent
import com.kaybo1.dev.kotlintest.Kcoin.adapter.model.DummyLoginModel
import com.kaybo1.dev.kotlintest.Kcoin.data.KcoinDataSource
import com.kaybo1.dev.kotlintest.Kcoin.data.model.Balance
import com.kaybo1.dev.kotlintest.home.view.data.DummyList
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import tech.thdev.base.presenter.BasePresenter
import tech.thdev.base.presenter.BaseView

/**
 * Created by Administrator on 2018-02-26.
 */
interface KcoinContract {
    interface View : BaseView {
        fun updateItem(balance: Balance)
        fun changePage(id : Int)
        fun dummyLogin(item : ArrayList<DummyList>)
        val onItemTouchListener : OnItemClickListener?
        fun setOnItemTouchListener(onTouch : (MotionEvent?, Int) -> Boolean)
    }
    interface Presenter : BasePresenter<View>{
        var kcoinDataSource : KcoinDataSource?

        var dummyLoginModel : DummyLoginModel?

        fun loadKcoinBalance()
    }
}