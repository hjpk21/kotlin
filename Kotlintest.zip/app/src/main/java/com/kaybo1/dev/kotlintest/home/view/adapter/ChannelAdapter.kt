package com.kaybo1.dev.kotlintest.home.view.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.home.view.adapter.holder.SampleView2Holder
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.*

/**
 * Created by Administrator on 2017-11-29.
 */
class ChannelAdapter(private val context: Context) : RecyclerView.Adapter<SampleView2Holder>(), ViewAdapterContract.ChannelModel,ViewAdapterContract.ChannelView {

    override fun addChannelItem(item: ChannelList) {
        Log.d("ChannelAdapter","addChannelItem")

        itemList.add(item)
    }

    val itemList: MutableList<ChannelList> = ArrayList()


    override fun onBindViewHolder(holder: SampleView2Holder?, position: Int) {
        Log.d("ChannelAdapter","onBindViewHolder")
        holder?.bindView(getItem(position),position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): SampleView2Holder {
        Log.d("ChannelAdapter","onCreateViewHolder")
        return SampleView2Holder(viewType, context, parent!!)
    }

    override fun getItemCount() = itemList.size

    override fun clear() {
        Log.d("ChannelAdapter","clear")
        itemList.clear()
    }

    private fun getItem(position: Int) = itemList.get(position)

    override fun reload() {
        Log.d("ChannelAdapter","reload")
        notifyDataSetChanged()
    }

}
