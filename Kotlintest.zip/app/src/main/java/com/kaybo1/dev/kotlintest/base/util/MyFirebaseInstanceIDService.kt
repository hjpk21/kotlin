package com.kaybo1.dev.kotlintest.base.util

import android.annotation.SuppressLint
import android.util.Log
import com.google.firebase.iid.FirebaseInstanceId
import com.google.firebase.iid.FirebaseInstanceIdService

@SuppressLint("Registered")
/**
 * Created by Administrator on 2018-02-22.
 */
class MyFirebaseInstanceIDService : FirebaseInstanceIdService() {
    private var TAG = "IDService"

    @SuppressLint("LongLogTag")
    override fun onTokenRefresh() {
        super.onTokenRefresh()
        val refreshedToken = FirebaseInstanceId.getInstance().token
        Log.d("TAG : [MyFirebaseInstanceIDService] "+TAG,"onTokenRefresh : "+refreshedToken!!)
        sendRegistrationToServer(refreshedToken)
    }

    private fun sendRegistrationToServer(token : String?) {
        //토큰을 웹서버로 보내 DB에 저정하도록 하는 동작 최초 앱이 설치될때 수행
    }

}