package com.kaybo1.dev.kotlintest.postDetailDummy.presenter

import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import tech.thdev.base.presenter.BasePresenter
import tech.thdev.base.presenter.BaseView

/**
 * Created by Administrator on 2018-02-27.
 */
interface PostDummyContract {
    interface View : BaseView {
        fun updateItem(item : PostDetailResponse)
    }

    interface Presenter : BasePresenter<View>{
        var postDetailDataSource : PostDetailDataSource?

        fun loadThumbInfo(thumb : Int)
    }
}