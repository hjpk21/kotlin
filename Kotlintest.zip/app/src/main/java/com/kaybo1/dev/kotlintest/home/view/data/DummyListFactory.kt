package com.kaybo1.dev.kotlintest.home.view.data

import android.content.Context
import com.kaybo1.dev.kotlintest.community.adapter.data.model.model.AllChannel

/**
 * Created by Administrator on 2017-11-28.
 */
open class DummyListFactory {

    val channelLists : ArrayList<ChannelList>
        get() {
            val result = ArrayList<ChannelList>()
            result.add(ChannelList("POINT BLACK","52","1","12","/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg","/thumbnail/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg?w=480&h=360","홈 등록<br> 테스트51111"))
            result.add(ChannelList("POINT BLACK","51","1","12","/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg","/thumbnail/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg?w=480&h=360","홈 등록<br> 테스트51112"))
            result.add(ChannelList("POINT BLACK","50","1","12","/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg","/thumbnail/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg?w=480&h=360","홈 등록<br> 테스트51113"))
            result.add(ChannelList("POINT BLACK","49","1","12","/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg","/thumbnail/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg?w=480&h=360","홈 등록<br> 테스트51114"))
            result.add(ChannelList("POINT BLACK","48","1","12","/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg","/thumbnail/download/1469083983422378/12905194_464624430403281_1901596781_n.jpg?w=480&h=360","홈 등록<br> 테스트51115"))
            return result
        }
    val bannerLists : ArrayList<BannerList>
        get(){
            val result = ArrayList<BannerList>()
            result.add(BannerList("38","/download/1509945417068774/main_640x200_sp.png","http://realcomics.kaybo1.com",""))
            result.add(BannerList("39","/download/1509945417068774/main_640x200_sp.png","http://realcomics.kaybo1.com",""))
            return result
        }

    val dummyLists : ArrayList<DummyList>
        get() {
            val result = ArrayList<DummyList>()
            result.add(DummyList("Kaybo",1,""))
            result.add(DummyList("Kaybo",2,""))
            result.add(DummyList("Kaybo",3,""))
            result.add(DummyList("Kaybo",4,""))
            return result
        }

    val loginDummyLists :ArrayList<DummyList>
        get() {
            val result = ArrayList<DummyList>()
            result.add(DummyList("Iniciar Sesion Con Facebook",1,"http://m.kaybo1.com/images/ico_login_s_facebook.jpg"))
            result.add(DummyList("Iniciar Sesion Con Google",2,"http://m.kaybo1.com/images/ico_login_s_google.jpg"))
            result.add(DummyList("Iniciar Sesion Con KAYBO",3,"http://m.kaybo1.com/images/ico_login_s_kaybo.jpg"))
            return result
        }

    val AllChannelDummyLists : ArrayList<AllChannel>
        get() {
            val result = ArrayList<AllChannel>()
            result.add(AllChannel("/download/1517804097998829/icon.png","61","Grand Chase M para KAYBO",true))
            result.add(AllChannel("/download/1506069800458080/icon.png","60","Astro Combat para KAYBO",true))
            result.add(AllChannel("/download/1504598529557907/icon.png","59","REAL COMICS",true))

            result.add(AllChannel("/download/1469561238765466/pb_Thumb_160x160.png","1",	"Ch. POINT BLANK",false))
            result.add(AllChannel(	"/download/1491268995109863/icon.png","2",	"Sniper Girls para KAYBO",false))
            result.add(AllChannel("/download/1469395147946369/manga_160x160.png","3","ANIME",false))
            result.add(AllChannel("/download/1469395062979545/football_Thumb_160x160.png","4","Ch. KAYBO FOOTBALL",false))
            result.add(AllChannel("/download/1469394998214049/gunz_Thumb_160x160.png","5","Ch. GUNZ ULTRA",false))
            result.add(AllChannel(	"/download/1469406410657542/오연왕_160x160.png","6","Ch. KING OF LOVE",false))
            result.add(AllChannel(	"/download/1472447971484168/music_2.png","7","Ch. MÚSICA",false))
            result.add(AllChannel(	"/download/1477994968015249/icon_160x160_1101.png","8","Ch. ASDA Global",false))
            result.add(AllChannel(	"/download/1469395039301597/cc_Thumb_160x160.png","9","Ch. Crazy Combi Turbo",false))
            result.add(AllChannel(	"/download/1483508159540425/ww1_icon.png","10","Ch. WW1 Air War",false))
            result.add(AllChannel(	"/download/1493359325616460/icon.png","11","Panzer of Alice",false))
            result.add(AllChannel(	"/download/1490871142864124/icon.png","12","Girls8line",false))
            result.add(AllChannel(	"/download/1488270810294038/icon.png","13","Aircombat 1918",false))
            result.add(AllChannel(	"/download/1479346541282351/mobile_combat_icon.png","14","Ch. Mobile Combat",false))
            result.add(AllChannel(	"/download/1475568995075300/icon_160x160.png","15","Ch. GIRLS GIRLS",false))
            result.add(AllChannel(	"/download/1470216639042879/코스프레_160x160.png","16","Ch. GALERÍA COSPLAY",false))
            result.add(AllChannel(	"/download/1469395013851939/mu_Thumb_160x160.png","19","Ch. MU Online",false))
            result.add(AllChannel(	"/download/1469407261480349/포켓몬_160x160.png","22",	"Ch. POKEMON GO",false))
            result.add(AllChannel(	"/download/1473065205549860/ic_dragonball_160.png","29","Ch. DRAGONBALL SUPER",false))

            result.add(AllChannel(	"/download/1472810218181494/overwatch.png","26","Ch. OVERWATCH",false))
            result.add(AllChannel(	"/download/1473214649115247/icon_160x160.png","30",	"Ch. Battle Squad",false))
            result.add(AllChannel(	"/download/1474540957439457/crashroyal.png","31","Ch. CLASH ROYALE",false))
            result.add(AllChannel(	"/download/1474541613336877/s-war.png","34","Ch. Summoners' War",false))
            result.add(AllChannel(	"/download/1476261240269553/icon_160x160.png","36",	"Ch. Sniper Trainer",false))
            result.add(AllChannel(	"/download/1477286797903279/minecraft-icon-0.png","37",	"Ch. MINECRAFT",false))
            result.add(AllChannel("/download/1479109348330087/racing_icon.png","40","Ch. Fuel Tap Racing",false))
            result.add(AllChannel(	"/download/1481260032448361/suttledown_icon.png","43",	"Ch. Shuttle Down",false))
            result.add(AllChannel(	"/download/1484806683840064/icon.png","46",	"Ch. TOP DOG",false))
            result.add(AllChannel(	"/download/1488169517095512/icon.png","47","Ch. Slash Dungeon",false))
            result.add(AllChannel(	"/download/1469407225404087/esports_160x160.png","62","Ch. KAYBO E-SPORTS",false))
            result.add(AllChannel(	"/download/1469406355882915/lotto_Thumb_160x160.png","64","Ch. KAYBO LOTTO",false))
            result.add(AllChannel(	"/download/1469395052382025/star_Thumb_160x160.png","65","Ch. KAYBO STAR",false))
            result.add(AllChannel("/download/1469406372285806/데몽헌터_160x160.png","66","Ch. DEMONG HUNTER 2",false))


            return result
        }
}