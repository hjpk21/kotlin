package com.kaybo1.dev.kotlintest.Channel.adapter.holder

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.Channel.data.model.PostList
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener
import com.kaybo1.dev.kotlintest.network.ImageDownload
import kotlinx.android.synthetic.main.list_channel.view.*


/**
 * Created by Administrator on 2018-02-07.
 */
@SuppressLint("LongLogTag")
class PostListViewHolder(context: Context, parent : ViewGroup?,var onItemClickListener: OnItemClickListener?) : BaseViewHolder<PostList>(R.layout.list_channel, context,parent){
    override fun bindView(item: PostList?, position: Int) {
        itemView?.let {
            with(it){
                //Log.d("TAG : [PostListViewHolder]","bindView :"+item)
                ImageDownload.loadImage(R.drawable.loading, channel_image_community, item?.getImageUrl())

                channel_nickname.text = item?.memberNickname
                channel_title.text = item?.title
                channel_reply.text = item?.commentCount
                channel_share.text = item?.shareCount
                channel_like.text = item?.likeCount

                it.setOnTouchListener { view, motionEvent ->
                    onItemClickListener?.onItemClick(motionEvent,position) ?: false
                }
            }
        }
    }

}