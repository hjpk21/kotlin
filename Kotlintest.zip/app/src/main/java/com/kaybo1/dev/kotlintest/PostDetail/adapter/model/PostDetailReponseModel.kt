package com.kaybo1.dev.kotlintest.PostDetail.adapter.model

import com.kaybo1.dev.kotlintest.PostDetail.data.Member
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse

/**
 * Created by Administrator on 2018-02-27.
 */
interface PostDetailReponseModel {
    var postDetailResponseItem : PostDetailResponse?
}