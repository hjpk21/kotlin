package com.kaybo1.dev.kotlintest.PostDetail.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.media.Image
import android.os.AsyncTask
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.util.Log
import com.kaybo1.dev.kotlintest.PostDetail.DummyPostDetailFragment
import com.kaybo1.dev.kotlintest.PostDetail.PostDetailFragment
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.PostDetailReponseModel
import com.kaybo1.dev.kotlintest.PostDetail.data.Member
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailPresenter

/**
 * Created by Administrator on 2018-02-27.
 */
@SuppressLint("LongLogTag")
class PostDetailResponseAdapter(fragmentManager: FragmentManager,val context: Context,val postId: Int) : FragmentPagerAdapter(fragmentManager) {

    override fun getItem(position: Int): Fragment {
        //Log.d("TAG : [PostDetailResponseAdapter] ","getItem = "+position)
        //Task(postId)!!.execute(null as Void?)
        return DummyPostDetailFragment.newInstance(context,postId)
    }

    override fun getCount(): Int = 1

    inner class Task internal constructor(private val postId : Int) : AsyncTask<Void, Void, Boolean>(){
        private lateinit var postDetailPresenter : PostDetailPresenter

        override fun doInBackground(vararg params: Void?): Boolean {
            Log.d("TAG : [PostDetailResponseAdapter] ","doInBackground ")
            Thread.sleep(2000)
            postDetailPresenter = PostDetailPresenter().apply {
                postDetailDataSource = PostDetailDataSource
            }
            postDetailPresenter.loadPostDetail(postId)
            return true

        }

    }
}