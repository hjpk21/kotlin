package com.kaybo1.dev.kotlintest.home.view.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.adapter.model.ViewAdapterContract
import com.kaybo1.dev.kotlintest.home.view.data.BannerList
import com.kaybo1.dev.kotlintest.home.view.data.ChannelList
import com.kaybo1.dev.kotlintest.home.view.data.HomeResponse
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener


/**
 * Created by Administrator on 2017-12-05.
 */
class BannerAdapter(private val context: Context) : RecyclerView.Adapter<BannerAdapter.bannerViewHolder>(), ViewAdapterContract.BannerModel, ViewAdapterContract.View, ViewAdapterContract.BannerView {


    override fun Viewreload() {
        Log.d("TAG","reload")
    }

    override fun addBannerItem(item: BannerList) {
        itemBannerList.add(item)
    }

    override fun onBindViewHolder(holder: bannerViewHolder?, position: Int) {
        Glide.with(context)
                .load(getBannerItem(position).getImage())
                .centerCrop()
                .placeholder(R.drawable.sample_00)
                .into(holder?.image)
    }

    val itemList: MutableList<ChannelList> = ArrayList()
    val itemBannerList : MutableList<BannerList> = ArrayList()

/*    override fun onBindViewHolder(holder: SampleView2Holder?, position: Int) {
        holder?.bindView(getItem(position),position)
    }*/

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): bannerViewHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.list_single,null)
        val mh = bannerViewHolder(v)
        return mh
        //return SampleView2Holder(viewType, context, parent!!)
    }

    override fun getItemCount() = itemBannerList.size

    override fun reload() {
        notifyDataSetChanged()
    }

    override fun clear() {
        itemBannerList.clear()
    }

    private fun getBannerItem(position: Int) = itemBannerList.get(position)

    inner class bannerViewHolder(view:View) : RecyclerView.ViewHolder(view) {
        val image : ImageView
        init {
            image = view.findViewById(R.id.image)
        }
    }

}