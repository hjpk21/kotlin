package com.kaybo1.dev.kotlintest.PostDetail

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.v4.view.ViewPager
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.MenuItem
import com.kaybo1.dev.kotlintest.PostDetail.adapter.PostContentsPagerAdapter
import com.kaybo1.dev.kotlintest.PostDetail.adapter.PostDetailResponseAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.PostContents
import com.kaybo1.dev.kotlintest.PostDetail.data.PostDetailResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsPagerAdapter
import com.kaybo1.dev.kotlintest.PostDetail.data.model.CommentsResponse
import com.kaybo1.dev.kotlintest.PostDetail.data.model.PostDetailDataSource
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailContract
import com.kaybo1.dev.kotlintest.PostDetail.presenter.PostDetailPresenter
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.network.ImageDownload

import kotlinx.android.synthetic.main.activity_postdetail.*
import kotlinx.android.synthetic.main.fragment_post_detail.*
import tech.thdev.base.view.BasePresenterActivity

/**
 * Created by Administrator on 2018-02-19.
 */

@SuppressLint("LongLogTag")
class PostDetailActivity : BasePresenterActivity<PostDetailContract.View, PostDetailContract.Presenter>(),ViewPager.OnPageChangeListener,PostDetailContract.View {

    var isLoading = true
    override fun updateItem(item: PostDetailResponse) {
        Log.d("TAG : [PostDetailActivity] ","updateItem = "+item.member)
        ImageDownload.loadImage(R.drawable.loading,postdetail_images,item.member.getProfileImagUrl())
        postdetail_text.text = item.member.nickName
        postContentItem(item.postContents)
    }
    private fun postContentItem(item:List<PostContents>){
        //board Content View
        Log.d("TAG : [PostDetailActivity] ","postContentItem")
        postContentPagerAdapter = PostContentsPagerAdapter(applicationContext,item)
        presenter?.postContentsPagerModel = postContentPagerAdapter
        postContent_recycler.adapter = postContentPagerAdapter
        postContent_recycler.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL,false)
        presenter?.loadComments(item[0].postId.toInt())

    }

    override fun commentItem(item: List<CommentsResponse>) {
        //댓글
        Log.d("TAG : [PostDetailActivity] ","commentItem = "+item)
        commentsPagerAdapter = CommentsPagerAdapter(applicationContext,item)
        presenter?.commentsPagerModel = commentsPagerAdapter
        postDetail_recycler.adapter = commentsPagerAdapter
        postDetail_recycler.layoutManager = LinearLayoutManager(applicationContext, LinearLayoutManager.VERTICAL,false)
        isLoading = false
    }

    override fun onCreatePresenter() = PostDetailPresenter()

    override fun onPageScrollStateChanged(state: Int) {

    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)

    }
    override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
        //이곳에서 댓글 페이징 처리

    }
    override fun onPageSelected(position: Int) {
        //여기 포지션으로 좌우 넘길때 채널/페이지 이동 가능
        Log.d("TAG : [PostDetailActivity] ", "onPageSelected : "+position.toString())
        when (position) {
            position -> Log.d("TAG : [PostDetailActivity] ","postion : "+position.toString())
        }
    }
    @SuppressLint("MissingSuperCall")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("TAG : [PostDetailActivity] ","onCreate")
        setContentView(R.layout.activity_postdetail)
        setSupportActionBar(toolbar)
        title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        presenter?.postDetailDataSource = PostDetailDataSource

        var postId = intent.getStringExtra("postId")
        postDetailResponseAdapter = PostDetailResponseAdapter(supportFragmentManager,applicationContext,postId.toInt())
        //presenter?.postDetailResponseModel = postDetailResponseAdapter
        postdetail_container.adapter = postDetailResponseAdapter
        postdetail_container.addOnPageChangeListener(this)

        presenter?.loadPostDetail(postId.toInt())
    }
    private var postDetailResponseAdapter : PostDetailResponseAdapter? = null

    private var commentsPagerAdapter : CommentsPagerAdapter? = null

    private var postContentPagerAdapter : PostContentsPagerAdapter? = null

}
