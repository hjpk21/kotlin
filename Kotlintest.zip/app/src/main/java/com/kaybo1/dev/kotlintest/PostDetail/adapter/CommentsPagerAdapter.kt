package com.kaybo1.dev.kotlintest.PostDetail.data.model

import android.annotation.SuppressLint
import android.content.Context
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.MotionEvent
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.PostDetail.adapter.holder.CommentsViewHolder
import com.kaybo1.dev.kotlintest.PostDetail.adapter.model.CommentsPagerModel
import com.kaybo1.dev.kotlintest.base.adapter.BaseViewHolder
import com.kaybo1.dev.kotlintest.listener.OnItemClickListener

/**
 * Created by Administrator on 2018-02-19.
 */
@SuppressLint("LongLogTag")
class CommentsPagerAdapter(private val context: Context, item:List<CommentsResponse>) : RecyclerView.Adapter<BaseViewHolder<CommentsResponse>>(), CommentsPagerModel {
    override var commentsResponse: List<CommentsResponse>? = item

    override var onItemTouchListener: OnItemClickListener? = null

    override fun setOnItemTouchListener(onTouch: (MotionEvent?, Int) -> Boolean) {
        onItemTouchListener = object : OnItemClickListener {
            override fun onItemClick(motionEvent: MotionEvent?, postion: Int): Boolean {
                Log.d("TAG : [CommentsPagerAdapter]","onItemClick")
                return onTouch(motionEvent,postion)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): BaseViewHolder<CommentsResponse> {
        Log.d("TAG : [CommentsPagerAdapter] ","onCreateViewHolder : "+onItemTouchListener)
        return CommentsViewHolder(context,parent,onItemTouchListener)
    }

    override fun onBindViewHolder(holder: BaseViewHolder<CommentsResponse>?, position: Int) {
        Log.d("TAG : [CommentsPagerAdapter] ","onBindViewHolder : "+position)
        holder?.bindView(getItem(position),position)
    }

    override fun getItemCount(): Int = commentsResponse?.size ?: 0

    private fun getItem(postion: Int) = commentsResponse?.get(postion)

}