package com.kaybo1.dev.kotlintest.base.util

import android.annotation.SuppressLint
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Created by Administrator on 2018-02-22.
 */
class MyFirebaseMessagingService : FirebaseMessagingService() {

    private val TAG = "MessagingService"

    @SuppressLint("LongLogTag")
    override fun onMessageReceived(remoteMessage: RemoteMessage?) {
        super.onMessageReceived(remoteMessage)
        if(remoteMessage!!.notification != null){
            Log.d("TAG : [MyFirebaseMessagingService] "+TAG,"onMessageReceived "+remoteMessage!!.from)
            Log.d(TAG,"${remoteMessage.notification?.body}")

            sendNotification(remoteMessage.notification?.body.toString())
        }

        if(remoteMessage.data.isNotEmpty()){
            //Log.d(TAG,"${remoteMessage.data} : This is DATA")
        }
    }
    fun sendNotification(messageBody : String) {

    }
}