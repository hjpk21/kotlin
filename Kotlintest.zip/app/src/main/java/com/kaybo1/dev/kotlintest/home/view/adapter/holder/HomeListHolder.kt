package com.kaybo1.dev.kotlintest.home.view.adapter.holder

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.kaybo1.dev.kotlintest.R
import com.kaybo1.dev.kotlintest.home.view.data.HomeResponse

import kotlinx.android.synthetic.main.list_item.view.*

/**
 * Created by Administrator on 2017-12-01.
 */
class HomeListHolder (resource : Int , context: Context, parent:ViewGroup) :
        RecyclerView.ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item,parent,false)){

    fun bindView(item:HomeResponse,position:Int){
        itemView.let {
            with(it){
                when(position){
                    0 -> itemTitle.text = item.info.recommendTitle
                    1 -> itemTitle.text = item.info.comicTitle
                    2 -> itemTitle.text = item.info.communityTitle
                }
            }
        }
    }

}