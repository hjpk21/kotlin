package com.kaybo1.dev.kotlintest.network

import com.kaybo1.dev.kotlintest.Kcoin.data.model.Balance
import retrofit2.Call
import retrofit2.http.GET

/**
 * Created by Administrator on 2018-02-26.
 */
interface KcoinServiceInterface {
    @GET("api/kcoin/balance")
    fun getKcoinBalance() : Call<Balance>
}